# KOMPRISMA KASIR V3 Professional 3.1

Upgrade dari MVP menjadi POS offline-first yang lebih siap dipakai.

## Peningkatan utama
- Dashboard omzet, transaksi, laba kotor, stok menipis, nilai persediaan.
- Kasir: pencarian, kategori, keranjang, kontrol qty, diskon transaksi, Tunai/Transfer/QRIS.
- Barcode scanner kamera.
- Produk: SKU/barcode, harga beli/jual, stok minimum, satuan, status stok.
- SQLite offline + migrasi database dari V3.0.
- Riwayat transaksi + detail transaksi.
- Export transaksi CSV.
- Struk PDF dan share/cetak melalui sistem Android.
- Identitas toko, footer struk, pajak, backup database.
- Menu Pengaturan sekarang benar-benar interaktif.

## Build cloud
GitHub Actions dapat menjalankan workflow yang membuat proyek Android dan build APK release.
Jangan menyimpan keystore/signing key di repository publik.


## Build 7 stability fixes
- Dashboard smoke test aman tanpa inisialisasi database native.
- Smoke test diperbaiki dan memeriksa tampilan dashboard utama.
- Workflow membuat Android platform otomatis sebelum release build.
- Analyze dan test tidak lagi disembunyikan dengan `|| true`.
- Tampilan subtotal keranjang diperbaiki agar menampilkan nilai sebenarnya.
