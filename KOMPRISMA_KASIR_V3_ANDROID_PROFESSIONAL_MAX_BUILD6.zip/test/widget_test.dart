import 'package:flutter_test/flutter_test.dart';
import 'package:komprisma_kasir_v3/main.dart';

void main() {
  testWidgets('KOMPRISMA app smoke test', (tester) async {
    await tester.pumpWidget(const KomprismaApp());
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.byType(KomprismaApp), findsOneWidget);
    expect(find.text('Ringkasan Hari Ini'), findsOneWidget);
  });
}
