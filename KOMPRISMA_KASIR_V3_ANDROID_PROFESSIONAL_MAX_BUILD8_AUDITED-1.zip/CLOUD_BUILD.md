# Cloud Build — KOMPRISMA KASIR V3

Workflow: `.github/workflows/android-apk.yml`

## What the workflow validates

The pipeline is intentionally strict. A build is considered successful only when all of these pass:

- source checkout;
- Flutter 3.24.5 stable is available;
- Android platform is generated only when `android/` is absent;
- dependencies resolve;
- Dart formatting check passes;
- `flutter analyze` passes;
- all Flutter tests pass;
- release APK builds successfully;
- the APK file exists and is non-empty;
- APK is uploaded as a GitHub Actions artifact.

The workflow runs on pushes to `main`, version tags (`v*`), and manual `workflow_dispatch` runs.

## How to use on GitHub

1. Upload/commit the entire BUILD8 source to the repository.
2. Open **Actions**.
3. Select **Build KOMPRISMA Android APK**.
4. Click **Run workflow** and choose `main`, or simply push a commit to `main`.
5. Wait until every step is green.
6. Open the successful workflow run and download the artifact `komprisma-kasir-v3-release`.

## Production signing

This BUILD8 produces an unsigned/debug-key release APK suitable for testing. For Play Store or official distribution, configure a production keystore through GitHub Secrets and add a dedicated signing configuration. Never commit a private keystore or passwords to the repository.
