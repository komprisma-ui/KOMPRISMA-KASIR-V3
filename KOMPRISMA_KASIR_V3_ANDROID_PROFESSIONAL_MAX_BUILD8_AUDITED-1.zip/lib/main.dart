import 'dart:io';
import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:sqflite/sqflite.dart';
import 'package:share_plus/share_plus.dart';
import 'db.dart';

String money(num v)=>NumberFormat.currency(locale:'id_ID',symbol:'Rp ',decimalDigits:0).format(v);
String dt(String? v)=>v==null?'-':DateFormat('dd/MM/yyyy HH:mm').format(DateTime.tryParse(v)?.toLocal()??DateTime.now());
num nval(String input){var s=input.trim().replaceAll(RegExp(r'[^0-9,.-]'),'');if(s.isEmpty)return 0;final negative=s.startsWith('-');s=s.replaceFirst(RegExp(r'^-'),'');final lastDot=s.lastIndexOf('.');final lastComma=s.lastIndexOf(',');if(lastDot>=0&&lastComma>=0){final decimal=lastDot>lastComma?'.':',';final thousand=decimal=='.'?',':'.';s=s.replaceAll(thousand,'').replaceFirst(decimal,'.');}else if(lastComma>=0){final decimals=s.length-lastComma-1;if(decimals<=2)s=s.replaceAll('.','').replaceFirst(',','.');else s=s.replaceAll(',','');}else if(lastDot>=0){final decimals=s.length-lastDot-1;if(decimals>2)s=s.replaceAll('.','');}final value=num.tryParse(s)??0;return negative?-value:value;}
void main()async{WidgetsFlutterBinding.ensureInitialized();await initializeDateFormatting('id_ID');await AppDb.instance.init();runApp(const KomprismaApp());}

class KomprismaApp extends StatelessWidget{const KomprismaApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'KOMPRISMA KASIR V3',theme:ThemeData(useMaterial3:true,colorSchemeSeed:const Color(0xFF345A88),scaffoldBackgroundColor:const Color(0xFFF5F7FA),cardTheme:const CardTheme(elevation:1,margin:EdgeInsets.zero),inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder(),filled:true,fillColor:Colors.white),navigationBarTheme:const NavigationBarThemeData(height:72),fontFamily:'sans-serif'),home:const Home());}

class Home extends StatefulWidget{const Home({super.key});@override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home>{int index=0;late final List<Widget> pages;final titles=['Dashboard','Kasir','Produk & Stok','Transaksi','Pengaturan','Pelanggan','Biaya Operasional','Laporan','Admin & Kasir','Audit Trail','Pembelian Stok','Mutasi Stok'];@override void initState(){super.initState();pages=const[Dashboard(),Pos(),Products(),Sales(),Settings(),Customers(),Expenses(),Reports(),Users(),Audit(),Purchases(),StockLog()];}void go(int i){if(i<0||i>=pages.length)return;if(mounted)setState(()=>index=i);final nav=Navigator.of(context);if(nav.canPop())nav.pop();} @override Widget build(BuildContext c){final wide=MediaQuery.of(c).size.width>=900;return Scaffold(appBar:AppBar(leading:Builder(builder:(bc)=>IconButton(onPressed:()=>Scaffold.of(bc).openDrawer(),icon:const Icon(Icons.menu_rounded))),title:Row(children:[Container(width:36,height:36,decoration:BoxDecoration(color:Theme.of(c).colorScheme.primary,borderRadius:BorderRadius.circular(10)),child:const Icon(Icons.storefront_rounded,color:Colors.white,size:20)),const SizedBox(width:10),Text(titles[index],style:const TextStyle(fontWeight:FontWeight.w900))]),actions:[IconButton(onPressed:()=>setState((){}),icon:const Icon(Icons.refresh_rounded)),Padding(padding:const EdgeInsets.only(right:12),child:CircleAvatar(radius:17,child:Text(index==1?'K':'A',style:const TextStyle(fontWeight:FontWeight.w800))))]),drawer:AppDrawer(selected:index,onSelect:go),body:wide?Row(children:[SizedBox(width:276,child:AppDrawer(selected:index,onSelect:go,embedded:true)),const VerticalDivider(width:1),Expanded(child:pages[index])]):pages[index],bottomNavigationBar:wide?null:NavigationBar(selectedIndex:[0,1,2,3,4].contains(index)?index:0,onDestinationSelected:go,destinations:const[NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Beranda'),NavigationDestination(icon:Icon(Icons.point_of_sale_outlined),selectedIcon:Icon(Icons.point_of_sale),label:'Kasir'),NavigationDestination(icon:Icon(Icons.inventory_2_outlined),selectedIcon:Icon(Icons.inventory_2),label:'Produk'),NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'Transaksi'),NavigationDestination(icon:Icon(Icons.menu_rounded),selectedIcon:Icon(Icons.menu_open_rounded),label:'Menu')],));}}

class AppDrawer extends StatelessWidget{final int selected;final ValueChanged<int> onSelect;final bool embedded;const AppDrawer({super.key,required this.selected,required this.onSelect,this.embedded=false});Widget section(String s)=>Padding(padding:const EdgeInsets.fromLTRB(18,16,18,5),child:Text(s.toUpperCase(),style:const TextStyle(color:Colors.white38,fontSize:10,fontWeight:FontWeight.w900,letterSpacing:1));Widget item(int i,IconData icon,String label){final a=selected==i;return Padding(padding:const EdgeInsets.symmetric(horizontal:10,vertical:1),child:ListTile(dense:true,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(10)),tileColor:a?Colors.white.withOpacity(.13):null,leading:Icon(icon,color:a?Colors.white:Colors.white70,size:21),title:Text(label,style:TextStyle(color:a?Colors.white:Colors.white70,fontWeight:a?FontWeight.w800:FontWeight.w600)),onTap:()=>onSelect(i)));}@override Widget build(BuildContext c){final content=SafeArea(child:Column(children:[Padding(padding:const EdgeInsets.fromLTRB(18,18,12,10),child:Row(children:[Container(width:44,height:44,decoration:BoxDecoration(color:Colors.white12,borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.storefront_rounded,color:Colors.white)),const SizedBox(width:10),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('KOMPRISMA',style:TextStyle(color:Colors.white,fontSize:19,fontWeight:FontWeight.w900)),Text('Manajemen Kasir Terpadu',style:TextStyle(color:Colors.white54,fontSize:10))]))])),if(!embedded)Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:OutlinedButton.icon(onPressed:()=>Navigator.of(c).maybePop(),icon:const Icon(Icons.close_rounded),label:const Text('Tutup Menu'),style:OutlinedButton.styleFrom(foregroundColor:Colors.white,side:const BorderSide(color:Colors.white24),minimumSize:const Size.fromHeight(42))),Expanded(child:ListView(padding:const EdgeInsets.only(top:4,bottom:8),children:[section('Utama'),item(0,Icons.dashboard_rounded,'Dashboard'),section('Operasional'),item(1,Icons.point_of_sale_rounded,'Kasir'),item(2,Icons.inventory_2_rounded,'Produk & Stok'),item(3,Icons.receipt_long_rounded,'Transaksi'),item(10,Icons.local_shipping_rounded,'Pembelian Stok'),item(11,Icons.swap_vert_rounded,'Mutasi Stok'),section('Pelanggan & Keuangan'),item(5,Icons.people_alt_rounded,'Pelanggan'),item(6,Icons.payments_outlined,'Biaya Operasional'),item(7,Icons.bar_chart_rounded,'Laporan'),section('Administrasi'),item(4,Icons.settings_rounded,'Pengaturan'),item(8,Icons.admin_panel_settings_rounded,'Admin & Kasir'),item(9,Icons.fact_check_rounded,'Audit Trail')])),Padding(padding:const EdgeInsets.fromLTRB(18,8,18,16),child:Text('Offline • SQLite • Professional',style:const TextStyle(color:Colors.white38,fontSize:10))) ]));return Drawer(width:276,backgroundColor:const Color(0xFF172033),child:content);}}

class Dashboard extends StatefulWidget{const Dashboard({super.key});@override State<Dashboard> createState()=>_DashboardState();}
class _DashboardState extends State<Dashboard>{late Future<Map<String,dynamic>> f;@override void initState(){super.initState();f=_safeDashboard();}Future<Map<String,dynamic>> _safeDashboard()async{try{return await AppDb.instance.dashboard();}catch(_){return const {};}}Future<void>reload()async{setState(()=>f=_safeDashboard());await f;}@override Widget build(BuildContext c)=>RefreshIndicator(onRefresh:reload,child:FutureBuilder(future:f,builder:(c,s){final d=s.data??{};return ListView(padding:const EdgeInsets.all(18),children:[Row(children:[const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Ringkasan Hari Ini',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),Text('Pantau penjualan, laba, stok dan biaya dalam satu layar.')])) ,FilledButton.icon(onPressed:()=>c.findAncestorStateOfType<_HomeState>()?.go(1),icon:const Icon(Icons.add),label:const Text('Transaksi Baru'))]),const SizedBox(height:18),GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:MediaQuery.of(c).size.width>700?4:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.5,children:[Stat('Omzet',money(d['omzet']??0),Icons.payments),Stat('Transaksi','${d['transactions']??0}',Icons.receipt_long),Stat('Laba Kotor',money(d['profit']??0),Icons.trending_up),Stat('Stok Menipis','${d['lowStock']??0}',Icons.warning_amber)]),const SizedBox(height:14),Card(child:Padding(padding:const EdgeInsets.all(18),child:Wrap(spacing:30,runSpacing:18,children:[Metric('Nilai Persediaan',money(d['stockValue']??0)),Metric('Biaya Hari Ini',money(d['expense']??0)),Metric('Laba Setelah Biaya',money((d['profit']??0)-(d['expense']??0))),Metric('Produk Aktif','${d['products']??0}')]))),const SizedBox(height:14),Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.offline_bolt)),title:const Text('Mode Offline Aktif',style:TextStyle(fontWeight:FontWeight.w900)),subtitle:const Text('Semua transaksi dan master data tersimpan di database lokal perangkat.'))),const SizedBox(height:14),Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Aksi Cepat',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:[ActionButton('Kasir',Icons.point_of_sale,1),ActionButton('Tambah Produk',Icons.add_box,2),ActionButton('Pelanggan',Icons.people,5),ActionButton('Biaya',Icons.payments,6),ActionButton('Laporan',Icons.bar_chart,7),ActionButton('Pengaturan',Icons.settings,4)])]))),const SizedBox(height:20),_lowStock()];}));}
Future<List<Map<String,dynamic>>> _safeLowStock()async{try{return await AppDb.instance.lowStock();}catch(_){return const [];}} Widget _lowStock()=>FutureBuilder(future:_safeLowStock(),builder:(c,s){final rows=s.data??[];return Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Perlu Perhatian',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),if(rows.isEmpty)const Text('Semua stok aman.'),...rows.take(5).map((x)=>ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.warning_amber_rounded),title:Text(x['name']),subtitle:Text('SKU ${x['sku']??'-'} • minimum ${x['min_stock']}'),trailing:Text('${x['stock']} ${x['unit']}',style:const TextStyle(fontWeight:FontWeight.w900))) ])));});}
class Stat extends StatelessWidget{final String a,b;final IconData icon;const Stat(this.a,this.b,this.icon,{super.key});@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Icon(icon,size:30),Text(a,style:TextStyle(color:Colors.grey.shade700)),Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900))])));}
class Metric extends StatelessWidget{final String a,b;const Metric(this.a,this.b,{super.key});@override Widget build(BuildContext c)=>SizedBox(width:220,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:TextStyle(color:Colors.grey.shade700)),const SizedBox(height:4),Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900))]));}
class ActionButton extends StatelessWidget{final String t;final IconData i;final int page;const ActionButton(this.t,this.i,this.page,{super.key});@override Widget build(BuildContext c)=>OutlinedButton.icon(onPressed:()=>c.findAncestorStateOfType<_HomeState>()?.go(page),icon:Icon(i),label:Text(t));}

class Pos extends StatefulWidget{const Pos({super.key});@override State<Pos> createState()=>_PosState();}
class _PosState extends State<Pos>{List<Map<String,dynamic>> items=[];List<String> cats=['Semua'];final Map<int,int> cart={};String q='',cat='Semua';num discount=0,tax=0;@override void initState(){super.initState();load();}Future<void>load()async{try{final loaded=await AppDb.instance.products(q,cat);final loadedCats=await AppDb.instance.categories();if(!mounted)return;items=loaded;cats=loadedCats;if(!cats.contains(cat))cat='Semua';setState((){});}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}}num subtotal()=>cart.entries.fold(0,(s,e){final x=items.where((p)=>p['id']==e.key);return x.isEmpty?s:s+(x.first['price'] as num)*e.value;});num total(){final base=(subtotal()-discount).clamp(0,double.infinity);return base+tax;}void add(Map<String,dynamic>x){final id=x['id'] as int;final qty=(cart[id]??0)+1;if(qty>(x['stock'] as num).toInt()){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Stok tidak mencukupi.')));return;}setState(()=>cart[id]=qty);}void remove(int id){setState((){if((cart[id]??0)<=1)cart.remove(id);else cart[id]=cart[id]!-1;});}Future<void>scan()async{String? code;bool done=false;await showDialog(context:context,builder:(dialogContext)=>Dialog(child:SizedBox(height:430,child:MobileScanner(onDetect:(cap){if(done||cap.barcodes.isEmpty)return;final value=cap.barcodes.first.rawValue;if(value==null||value.isEmpty)return;done=true;code=value;Navigator.of(dialogContext).pop();})))) ;if(code!=null){q=code!;cat='Semua';await load();if(items.isNotEmpty)add(items.first);}}Future<void>discountDialog()async{final x=TextEditingController(text:discount.toStringAsFixed(0));final v=await showDialog<num>(context:context,builder:(_)=>AlertDialog(title:const Text('Diskon Transaksi'),content:TextField(controller:x,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Nominal diskon')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(context,nval(x.text)),child:const Text('Terapkan'))]));if(v!=null)setState(()=>discount=v.clamp(0,subtotal()));}Future<void>checkout()async{if(cart.isEmpty)return;final cash=TextEditingController(text:total().toStringAsFixed(0));String method='Tunai';num taxPct=nval((await AppDb.instance.settings())['tax_percent']??'0');final calcTax=((subtotal()-discount).clamp(0,double.infinity))*taxPct/100;tax=calcTax;final ok=await showDialog<bool>(context:context,builder:(_)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('Pembayaran'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[Text('Subtotal ${money(subtotal())}'),if(discount>0)Text('Diskon -${money(discount)}'),Text('Pajak ${money(tax)}'),Text('TOTAL ${money(total())}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:12),DropdownButtonFormField<String>(value:method,items:['Tunai','Transfer','QRIS','Debit/Kartu'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>method=v??'Tunai')),if(method=='Tunai')TextField(controller:cash,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Uang diterima'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Simpan Transaksi'))]));if(ok==true){final received=method=='Tunai'?nval(cash.text):total();try{final inv=await AppDb.instance.sale(cart,subtotal(),discount,tax,total(),received,method);final change=received-total();setState((){cart.clear();discount=0;tax=0;});if(mounted)showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Transaksi Berhasil'),content:Text('$inv\nKembalian: ${money(change)}'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Selesai'))]));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}}}
@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.fromLTRB(12,12,12,6),child:Row(children:[Expanded(child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari nama, SKU atau kategori'),onChanged:(v){q=v;load();})),IconButton.filled(onPressed:scan,icon:const Icon(Icons.qr_code_scanner))])),SizedBox(height:44,child:ListView.separated(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:12),itemCount:cats.length,itemBuilder:(c,i)=>ChoiceChip(label:Text(cats[i]),selected:cat==cats[i],onSelected:(_){cat=cats[i];load();}),separatorBuilder:(_,__)=>const SizedBox(width:8))),Expanded(child:LayoutBuilder(builder:(c,con){final grid=GridView.builder(padding:const EdgeInsets.all(12),gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:con.maxWidth>800?3:2,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.25),itemCount:items.length,itemBuilder:(c,i){final x=items[i];final qy=cart[x['id']]??0;return Card(child:InkWell(onTap:()=>add(x),child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(x['name'],maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w800))),if(qy>0)CircleAvatar(radius:12,child:Text('$qy',style:const TextStyle(fontSize:11)))]),const Spacer(),Text(money(x['price']),style:const TextStyle(fontWeight:FontWeight.w900)),Text('Stok ${x['stock']} ${x['unit']}')]))));});if(con.maxWidth>800)return Row(children:[Expanded(child:grid),SizedBox(width:330,child:Cart(cart:cart,items:items,subtotal:subtotal(),discount:discount,total:total(),remove:remove,discountEdit:discountDialog,pay:checkout))]);return grid;})),if(MediaQuery.of(c).size.width<=800)SafeArea(child:Padding(padding:const EdgeInsets.all(12),child:FilledButton.icon(onPressed:cart.isEmpty?null:checkout,icon:const Icon(Icons.payments),label:Text('Bayar • ${money(total())}'))))]);}
}
class Cart extends StatelessWidget{final Map<int,int> cart;final List<Map<String,dynamic>> items;final num subtotal,discount,total;final void Function(int) remove;final VoidCallback discountEdit,pay;const Cart({super.key,required this.cart,required this.items,required this.subtotal,required this.discount,required this.total,required this.remove,required this.discountEdit,required this.pay});@override Widget build(BuildContext c)=>Card(child:Column(children:[const ListTile(title:Text('Keranjang',style:TextStyle(fontWeight:FontWeight.w900)),leading:Icon(Icons.shopping_cart)),Expanded(child:ListView(padding:const EdgeInsets.symmetric(horizontal:8),children:cart.entries.map((e){final x=items.firstWhere((p)=>p['id']==e.key);return ListTile(title:Text(x['name']),subtitle:Text('${e.value} × ${money(x['price'])}'),trailing:IconButton(onPressed:()=>remove(e.key),icon:const Icon(Icons.remove_circle_outline)));}).toList())),Padding(padding:const EdgeInsets.all(14),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Subtotal'),Text(money(subtotal))]),if(discount>0)Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Diskon'),Text('-${money(discount)}')]),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('TOTAL',style:TextStyle(fontWeight:FontWeight.w900)),Text(money(total),style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900))]),const SizedBox(height:8),Row(children:[Expanded(child:OutlinedButton(onPressed:discountEdit,child:const Text('Diskon'))),const SizedBox(width:8),Expanded(child:FilledButton(onPressed:pay,child:const Text('Bayar')))])]))]));}

class Products extends StatefulWidget{const Products({super.key});@override State<Products> createState()=>_ProductsState();}
class _ProductsState extends State<Products>{List<Map<String,dynamic>> rows=[];String q='';@override void initState(){super.initState();load();}Future<void>load()async{try{rows=await AppDb.instance.products(q);if(mounted)setState((){});}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}}Future<void>edit([Map<String,dynamic>? x])async{final n=TextEditingController(text:x?['name']??''),sku=TextEditingController(text:x?['sku']??''),cat=TextEditingController(text:x?['category']??'Umum'),buy=TextEditingController(text:'${x?['buy_price']??0}'),price=TextEditingController(text:'${x?['price']??0}'),stock=TextEditingController(text:'${x?['stock']??0}'),min=TextEditingController(text:'${x?['min_stock']??3}'),unit=TextEditingController(text:x?['unit']??'pcs');final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(x==null?'Tambah Produk':'Edit Produk'),content:SingleChildScrollView(child:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nama produk')),TextField(controller:sku,decoration:const InputDecoration(labelText:'SKU / Barcode')),TextField(controller:cat,decoration:const InputDecoration(labelText:'Kategori')),Row(children:[Expanded(child:TextField(controller:buy,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Harga beli'))),const SizedBox(width:8),Expanded(child:TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Harga jual')))]),Row(children:[Expanded(child:TextField(controller:stock,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stok'))),const SizedBox(width:8),Expanded(child:TextField(controller:min,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Min. stok')))]),TextField(controller:unit,decoration:const InputDecoration(labelText:'Satuan'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Simpan'))]));if(ok==true){if(n.text.trim().isEmpty)return;try{await AppDb.instance.upsertProduct({'id':x?['id'],'name':n.text.trim(),'sku':sku.text.trim().isEmpty?'SKU-${DateTime.now().millisecondsSinceEpoch}':sku.text.trim(),'category':cat.text.trim().isEmpty?'Umum':cat.text.trim(),'buy_price':nval(buy.text),'price':nval(price.text),'stock':int.tryParse(stock.text)??0,'min_stock':int.tryParse(min.text)??3,'unit':unit.text.trim().isEmpty?'pcs':unit.text.trim(),'active':1});await load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}}}
@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari produk, SKU, kategori'),onChanged:(v){q=v;load();})),const SizedBox(width:8),FilledButton.icon(onPressed:()=>edit(),icon:const Icon(Icons.add),label:const Text('Produk Baru'))])),Expanded(child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:12),itemCount:rows.length,itemBuilder:(c,i){final x=rows[i];final low=(x['stock'] as num)<= (x['min_stock'] as num);return Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.inventory_2)),title:Text(x['name'],style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${x['sku']} • ${x['category']} • beli ${money(x['buy_price'])}'),trailing:SizedBox(width:150,child:Row(mainAxisAlignment:MainAxisAlignment.end,children:[Text('${x['stock']} ${x['unit']}',style:TextStyle(fontWeight:FontWeight.w900,color:low?Colors.red:null)),IconButton(onPressed:()=>edit(x),icon:const Icon(Icons.edit)),PopupMenuButton<String>(onSelected:(v)async{if(v=='in')await AppDb.instance.adjustStock(x['id'],1,'Penambahan manual');if(v=='out')await AppDb.instance.adjustStock(x['id'],-1,'Pengurangan manual');if(v=='del')await AppDb.instance.deleteProduct(x['id']);await load();},itemBuilder:(_)=>const[PopupMenuItem(value:'in',child:Text('Stok +1')),PopupMenuItem(value:'out',child:Text('Stok -1')),PopupMenuItem(value:'del',child:Text('Arsipkan'))]))])));},separatorBuilder:(_,__)=>const SizedBox(height:8))]);}
}

class Sales extends StatefulWidget{const Sales({super.key});@override State<Sales> createState()=>_SalesState();}
class _SalesState extends State<Sales>{String range='Hari Ini',q='';Future<void>exportCsv()async{final r=await AppDb.instance.sales(range:range,q:q);final data=[['Invoice','Tanggal','Kasir','Metode','Subtotal','Diskon','Pajak','Total','Diterima'],...r.map((x)=>[x['invoice'],dt(x['created_at']),x['cashier'],x['payment_method'],x['subtotal'],x['discount'],x['tax'],x['total'],x['received']])];final csv=const ListToCsvConverter().convert(data);final dir=await getApplicationDocumentsDirectory();final f=File(p.join(dir.path,'KOMPRISMA_TRANSAKSI_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.csv'));await f.writeAsString(csv);await Share.shareXFiles([XFile(f.path)],text:'Laporan transaksi KOMPRISMA');}@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Wrap(spacing:8,runSpacing:8,crossAxisAlignment:WrapCrossAlignment.center,children:[const Text('Riwayat Transaksi',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),SizedBox(width:260,child:TextField(decoration:InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari invoice/kasir'),onChanged:(v){q=v;setState((){});})),DropdownButton<String>(value:range,items:['Hari Ini','7 Hari','Bulan Ini','Semua'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>range=v!)),IconButton.filled(onPressed:exportCsv,icon:const Icon(Icons.download))])),Expanded(child:FutureBuilder(future:AppDb.instance.sales(range:range,q:q),builder:(c,s){final r=s.data??[];return ListView.separated(padding:const EdgeInsets.symmetric(horizontal:12),itemCount:r.length,itemBuilder:(c,i){final x=r[i];return Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.receipt_long)),title:Text(x['invoice'],style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${dt(x['created_at'])} • ${x['cashier']??'-'} • ${x['payment_method']}'),trailing:Text(money(x['total']),style:const TextStyle(fontWeight:FontWeight.w900)),onTap:()=>detail(x)));},separatorBuilder:(_,__)=>const SizedBox(height:8));}))]);}Future<void>detail(Map<String,dynamic>x)async{final items=await AppDb.instance.saleItems(x['id']);if(!mounted)return;showModalBottomSheet(context:context,isScrollControlled:true,showDragHandle:true,builder:(_)=>Padding(padding:const EdgeInsets.all(20),child:ListView(shrinkWrap:true,children:[Text(x['invoice'],style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text('${dt(x['created_at'])} • ${x['payment_method']}'),const Divider(),...items.map((i)=>ListTile(contentPadding:EdgeInsets.zero,title:Text(i['name']??'Produk'),subtitle:Text('${i['qty']} × ${money(i['price'])}'),trailing:Text(money((i['qty'] as num)*(i['price'] as num)))),),const Divider(),Text('Subtotal ${money(x['subtotal']??0)}'),Text('Diskon ${money(x['discount']??0)}'),Text('Pajak ${money(x['tax']??0)}'),Text('TOTAL ${money(x['total'])}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),FilledButton.icon(onPressed:()=>receipt(x,items),icon:const Icon(Icons.print),label:const Text('Cetak / Bagikan Struk'))])));}Future<void>receipt(Map<String,dynamic> x,List<Map<String,dynamic>> items)async{
  final st=await AppDb.instance.settings();
  String txt(Object? v)=>v?.toString()??'';
  num val(Object? v)=>v is num?v:nval(txt(v));
  final doc=pw.Document();
  doc.addPage(pw.Page(build:(context)=>pw.Column(
    crossAxisAlignment:pw.CrossAxisAlignment.start,
    children:[
      pw.Text(txt(st['store_name']).isEmpty?'KOMPRISMA STORE':txt(st['store_name']),style:pw.TextStyle(fontSize:18,fontWeight:pw.FontWeight.bold)),
      pw.Text(txt(st['address'])),
      pw.Text(txt(st['phone'])),
      pw.SizedBox(height:12),
      pw.Text(txt(x['invoice'])),
      pw.Text(dt(txt(x['created_at']))),
      pw.Divider(),
      ...items.map((i)=>pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[
        pw.Expanded(child:pw.Text('${txt(i['name'])} x${txt(i['qty'])}')),
        pw.Text(money(val(i['qty'])*val(i['price']))),
      ])),
      pw.Divider(),
      pw.Text('Subtotal ${money(val(x['subtotal']))}'),
      pw.Text('Diskon ${money(val(x['discount']))}'),
      pw.Text('Pajak ${money(val(x['tax']))}'),
      pw.Text('TOTAL ${money(val(x['total']))}'),
      pw.Text(txt(st['receipt_footer'])),
    ],
  )));
  final invoice=txt(x['invoice']).isEmpty?'KOMPRISMA_STRUK':txt(x['invoice']);
  await Printing.sharePdf(bytes:await doc.save(),filename:'$invoice.pdf');
}

class Customers extends StatefulWidget{const Customers({super.key});@override State<Customers> createState()=>_CustomersState();}
class _CustomersState extends State<Customers>{List<Map<String,dynamic>> rows=[];@override void initState(){super.initState();load();}Future<void>load()async{rows=await AppDb.instance.customers();if(mounted)setState((){});}Future<void>edit([Map<String,dynamic>? x])async{final n=TextEditingController(text:x?['name']??''),ph=TextEditingController(text:x?['phone']??''),a=TextEditingController(text:x?['address']??''),no=TextEditingController(text:x?['notes']??'');final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(x==null?'Pelanggan Baru':'Edit Pelanggan'),content:SingleChildScrollView(child:Column(children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nama')),TextField(controller:ph,decoration:const InputDecoration(labelText:'Telepon')),TextField(controller:a,decoration:const InputDecoration(labelText:'Alamat')),TextField(controller:no,decoration:const InputDecoration(labelText:'Catatan'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Simpan'))]));if(ok==true&&n.text.trim().isNotEmpty){await AppDb.instance.saveCustomer({'id':x?['id'],'name':n.text.trim(),'phone':ph.text,'address':a.text,'notes':no.text,'active':1});await load();}}@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[const Expanded(child:Text('Pelanggan',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900))),FilledButton.icon(onPressed:()=>edit(),icon:const Icon(Icons.person_add),label:const Text('Tambah'))])),Expanded(child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:12),itemCount:rows.length,itemBuilder:(c,i){final x=rows[i];return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(x['name'],style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${x['phone']??''}\n${x['address']??''}'),isThreeLine:true,onTap:()=>edit(x),trailing:IconButton(onPressed:()async{await AppDb.instance.deleteCustomer(x['id']);await load();},icon:const Icon(Icons.delete_outline)));},separatorBuilder:(_,__)=>const SizedBox(height:8))]);}}

class Expenses extends StatefulWidget{const Expenses({super.key});@override State<Expenses> createState()=>_ExpensesState();}
class _ExpensesState extends State<Expenses>{String range='Hari Ini';Future<void>add()async{final t=TextEditingController(),cat=TextEditingController(text:'Operasional'),amt=TextEditingController(),note=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Catat Biaya'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:t,decoration:const InputDecoration(labelText:'Nama biaya')),TextField(controller:cat,decoration:const InputDecoration(labelText:'Kategori')),TextField(controller:amt,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Nominal')),TextField(controller:note,decoration:const InputDecoration(labelText:'Catatan'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Simpan'))]));if(ok==true&&t.text.isNotEmpty){try{await AppDb.instance.addExpense(t.text,cat.text,nval(amt.text),note.text);if(mounted)setState((){});}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}}}@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[const Expanded(child:Text('Biaya Operasional',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900))),DropdownButton<String>(value:range,items:['Hari Ini','Bulan Ini','Semua'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>range=v!)),IconButton.filled(onPressed:add,icon:const Icon(Icons.add))])),Expanded(child:FutureBuilder(future:AppDb.instance.expenses(range:range),builder:(c,s){final r=s.data??[];return ListView.separated(padding:const EdgeInsets.symmetric(horizontal:12),itemCount:r.length,itemBuilder:(c,i)=>Card(child:ListTile(leading:const Icon(Icons.payments),title:Text(r[i]['title'],style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${r[i]['category']} • ${dt(r[i]['created_at'])}'),trailing:Text(money(r[i]['amount']),style:const TextStyle(fontWeight:FontWeight.w900))),),separatorBuilder:(_,__)=>const SizedBox(height:8));}))]);}}

class Reports extends StatelessWidget{const Reports({super.key});@override Widget build(BuildContext c)=>FutureBuilder(future:AppDb.instance.dashboard(),builder:(c,s){final d=s.data??{};return ListView(padding:const EdgeInsets.all(18),children:[const Text('Laporan & Analitik',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Ringkasan operasional untuk membantu pengambilan keputusan.'),const SizedBox(height:18),Wrap(spacing:12,runSpacing:12,children:[_box('Omzet Hari Ini',money(d['omzet']??0),Icons.payments),_box('Laba Kotor',money(d['profit']??0),Icons.trending_up),_box('Biaya',money(d['expense']??0),Icons.money_off),_box('Laba Bersih',money((d['profit']??0)-(d['expense']??0)),Icons.account_balance_wallet)]),const SizedBox(height:18),Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Insight',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('Produk aktif: ${d['products']??0}'),Text('Stok menipis: ${d['lowStock']??0}'),Text('Nilai persediaan: ${money(d['stockValue']??0)}'),const SizedBox(height:10),const Text('Untuk laporan periode lengkap, gunakan menu Transaksi dan filter periode. Export CSV tersedia untuk pengolahan lanjutan.')]))) ]);});}Widget _box(String a,String b,IconData i)=>SizedBox(width:230,child:Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(i),const SizedBox(height:12),Text(a),Text(b,style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900))])));}

class Settings extends StatefulWidget {
  const Settings({super.key});

  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  Map<String, String> settings = {};

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final value = await AppDb.instance.settings();
    if (!mounted) return;
    setState(() => settings = value);
  }

  Widget tile(
    IconData icon,
    String title,
    String subtitle,
    VoidCallback action,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: action,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        const Text(
          'Pengaturan',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 4),
        const Text(
          'Konfigurasi toko, transaksi, printer dan keamanan.',
        ),
        const SizedBox(height: 16),
        tile(
          Icons.store,
          'Identitas Toko',
          'Nama, alamat, telepon dan footer struk',
          () => store(context),
        ),
        tile(
          Icons.receipt_long,
          'Struk & Printer',
          'Ukuran struk dan informasi cetak',
          () => receipt(context),
        ),
        tile(
          Icons.percent,
          'Pajak Penjualan',
          'Atur persentase pajak otomatis',
          () => tax(context),
        ),
        tile(
          Icons.qr_code_scanner,
          'Barcode Scanner',
          'Uji scanner kamera dan pencarian SKU',
          () => scan(context),
        ),
        tile(
          Icons.backup,
          'Backup Database',
          'Buat salinan database dan bagikan',
          () => backup(context),
        ),
        tile(
          Icons.tune,
          'Preferensi',
          'Mata uang dan tema aplikasi',
          () => preferences(context),
        ),
        tile(
          Icons.info_outline,
          'Tentang KOMPRISMA',
          'Versi dan informasi aplikasi',
          () => about(context),
        ),
        const SizedBox(height: 8),
        Card(
          child: ListTile(
            leading: const Icon(Icons.verified),
            title: const Text(
              'KOMPRISMA KASIR V3 Professional',
              style: TextStyle(fontWeight: FontWeight.w900),
            ),
            subtitle: const Text(
              'Offline-first • POS • Stok • Pelanggan • Biaya • Laporan • Audit Trail',
            ),
          ),
        ),
      ],
    );
  }

  Future<void> store(BuildContext context) async {
    final current = await AppDb.instance.settings();

    final name = TextEditingController(text: current['store_name'] ?? '');
    final address = TextEditingController(text: current['address'] ?? '');
    final phone = TextEditingController(text: current['phone'] ?? '');
    final footer =
        TextEditingController(text: current['receipt_footer'] ?? '');

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Identitas Toko'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: name,
                decoration: const InputDecoration(labelText: 'Nama toko'),
              ),
              TextField(
                controller: address,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'Alamat'),
              ),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'Telepon'),
              ),
              TextField(
                controller: footer,
                maxLines: 2,
                decoration:
                    const InputDecoration(labelText: 'Footer struk'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );

    if (saved != true) return;

    await AppDb.instance.setSettings({
      'store_name': name.text.trim(),
      'address': address.text.trim(),
      'phone': phone.text.trim(),
      'receipt_footer': footer.text.trim(),
    });

    await _loadSettings();
  }

  Future<void> receipt(BuildContext context) async {
    final current = await AppDb.instance.settings();
    final size =
        TextEditingController(text: current['printer_size'] ?? '58 mm');

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Struk & Printer'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              value: ['58 mm', '80 mm', 'A4'].contains(size.text)
                  ? size.text
                  : '58 mm',
              items: ['58 mm', '80 mm', 'A4']
                  .map(
                    (value) => DropdownMenuItem(
                      value: value,
                      child: Text(value),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                size.text = value ?? '58 mm';
              },
              decoration: const InputDecoration(
                labelText: 'Ukuran kertas',
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Pencetakan menggunakan layanan Android/PDF yang tersedia pada perangkat. '
              'Printer Bluetooth/USB dapat dipilih melalui dialog cetak Android.',
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );

    if (saved != true) return;

    await AppDb.instance.setSettings({
      'printer_size': size.text,
    });

    await _loadSettings();
  }

  Future<void> tax(BuildContext context) async {
    final current = await AppDb.instance.settings();
    final controller =
        TextEditingController(text: current['tax_percent'] ?? '0');

    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Pajak Penjualan'),
        content: TextField(
          controller: controller,
          keyboardType: const TextInputType.numberWithOptions(
            decimal: true,
          ),
          decoration: const InputDecoration(
            labelText: 'Pajak (%)',
            hintText: 'Contoh: 11',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () {
              final raw = controller.text.trim().replaceAll(',', '.');
              final parsed = double.tryParse(raw);

              if (parsed == null || parsed < 0 || parsed > 100) {
                return;
              }

              Navigator.pop(dialogContext, raw);
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );

    if (value == null) return;

    await AppDb.instance.setSettings({
      'tax_percent': value,
    });

    await _loadSettings();
  }

  Future<void> scan(BuildContext context) async {
    String? code;
    bool done = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        child: SizedBox(
          height: 430,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Scan Barcode',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              Expanded(
                child: MobileScanner(
                  onDetect: (capture) {
                    if (done || capture.barcodes.isEmpty) return;

                    final value = capture.barcodes.first.rawValue;
                    if (value == null || value.isEmpty) return;

                    done = true;
                    code = value;
                    Navigator.of(dialogContext).pop();
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (!mounted || code == null) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Barcode terbaca: $code')),
    );
  }

  Future<void> backup(BuildContext context) async {
    final source = File(
      p.join(
        await getDatabasesPath(),
        'komprisma_v3.db',
      ),
    );

    if (!await source.exists()) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Database belum tersedia untuk di-backup.'),
        ),
      );
      return;
    }

    final directory = await getApplicationDocumentsDirectory();

    final destination = File(
      p.join(
        directory.path,
        'KOMPRISMA_BACKUP_${DateFormat('yyyyMMdd_HHmmss').format(DateTime.now())}.db',
      ),
    );

    await source.copy(destination.path);

    if (!mounted) return;

    await Share.shareXFiles(
      [XFile(destination.path)],
      text: 'Backup database KOMPRISMA KASIR V3',
    );
  }

  Future<void> preferences(BuildContext context) async {
    final current = await AppDb.instance.settings();

    final currency =
        TextEditingController(text: current['currency'] ?? 'Rp');
    String theme = current['theme'] ?? 'Sistem';

    final value = await showDialog<List<String>>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) {
          return AlertDialog(
            title: const Text('Preferensi'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: currency,
                  decoration: const InputDecoration(
                    labelText: 'Simbol mata uang',
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: ['Sistem', 'Terang', 'Gelap'].contains(theme)
                      ? theme
                      : 'Sistem',
                  items: ['Sistem', 'Terang', 'Gelap']
                      .map(
                        (value) => DropdownMenuItem(
                          value: value,
                          child: Text(value),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    setDialogState(() => theme = value ?? 'Sistem');
                  },
                  decoration: const InputDecoration(
                    labelText: 'Tema',
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Batal'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(
                  dialogContext,
                  [currency.text.trim(), theme],
                ),
                child: const Text('Simpan'),
              ),
            ],
          );
        },
      ),
    );

    if (value == null) return;

    await AppDb.instance.setSettings({
      'currency': value[0].isEmpty ? 'Rp' : value[0],
      'theme': value[1],
    });

    await _loadSettings();
  }

  Future<void> about(BuildContext context) async {
    showAboutDialog(
      context: context,
      applicationName: 'KOMPRISMA KASIR V3',
      applicationVersion: 'Professional',
      applicationLegalese: 'Offline POS • SQLite • Android',
    );
  }
}

class Users extends StatefulWidget{const Users({super.key});@override State<Users> createState()=>_UsersState();}
class _UsersState extends State<Users>{List<Map<String,dynamic>>rows=[];@override void initState(){super.initState();load();}Future<void>load()async{rows=await AppDb.instance.users();if(mounted)setState((){});}Future<void>edit([Map<String,dynamic>?x])async{final n=TextEditingController(text:x?['name']??''),pin=TextEditingController(text:x?['pin']??'');String role=x?['role']??'Kasir';final ok=await showDialog<bool>(context:context,builder:(_)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:Text(x==null?'Tambah Pengguna':'Edit Pengguna'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nama')),DropdownButtonFormField<String>(value:role,items:['Admin','Kasir','Supervisor'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>role=v??'Kasir')),TextField(controller:pin,obscureText:true,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'PIN (opsional)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Simpan'))]));if(ok==true&&n.text.isNotEmpty){try{await AppDb.instance.saveUser({'id':x?['id'],'name':n.text,'role':role,'pin':pin.text,'active':1});await load();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}}}@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[const Expanded(child:Text('Admin & Kasir',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900))),FilledButton.icon(onPressed:()=>edit(),icon:const Icon(Icons.person_add),label:const Text('Tambah'))])),Expanded(child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:12),itemCount:rows.length,itemBuilder:(c,i)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(rows[i]['name'],style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${rows[i]['role']} • PIN ${rows[i]['pin'].toString().isEmpty?'belum diatur':'tersedia'}'),onTap:()=>edit(rows[i]),trailing:IconButton(onPressed:()async{await AppDb.instance.deleteUser(rows[i]['id']);await load();},icon:const Icon(Icons.delete_outline)))),separatorBuilder:(_,__)=>const SizedBox(height:8))]);}}

class Audit extends StatelessWidget{const Audit({super.key});@override Widget build(BuildContext c)=>FutureBuilder(future:AppDb.instance.audit(),builder:(c,s){final r=s.data??[];return Column(children:[const Padding(padding:EdgeInsets.all(14),child:Align(alignment:Alignment.centerLeft,child:Text('Audit Trail',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)))),Expanded(child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:12),itemCount:r.length,itemBuilder:(c,i)=>Card(child:ListTile(leading:const Icon(Icons.history),title:Text(r[i]['action'],style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${r[i]['detail']}\n${r[i]['user_name']} • ${dt(r[i]['created_at'])}'),isThreeLine:true)),separatorBuilder:(_,__)=>const SizedBox(height:6)))]);});}}

class StockLog extends StatelessWidget{const StockLog({super.key});@override Widget build(BuildContext c)=>FutureBuilder(future:AppDb.instance.movementLog(),builder:(c,s){final r=s.data??[];return Column(children:[const Padding(padding:EdgeInsets.all(14),child:Align(alignment:Alignment.centerLeft,child:Text('Mutasi Stok',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)))),Expanded(child:ListView.separated(padding:const EdgeInsets.symmetric(horizontal:12),itemCount:r.length,itemBuilder:(c,i)=>Card(child:ListTile(leading:Icon(r[i]['type']=='MASUK'?Icons.arrow_downward:Icons.arrow_upward),title:Text('${r[i]['name']??'Produk'} • ${r[i]['type']}'),subtitle:Text('${r[i]['note']??''} • ${dt(r[i]['created_at'])}'),trailing:Text('${r[i]['qty']}',style:const TextStyle(fontWeight:FontWeight.w900)))),separatorBuilder:(_,__)=>const SizedBox(height:6)))]);});}}

class Purchases extends StatefulWidget{const Purchases({super.key});@override State<Purchases> createState()=>_PurchasesState();}
class _PurchasesState extends State<Purchases>{List<Map<String,dynamic>>products=[];final Map<int,int>cart={};final supplier=TextEditingController();@override void initState(){super.initState();load();}Future<void>load()async{products=await AppDb.instance.products();if(mounted)setState((){});}Future<void>save()async{if(cart.isEmpty){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Pilih minimal satu produk.')));return;}try{await AppDb.instance.addPurchase(supplier.text,cart);cart.clear();supplier.clear();await load();if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Pembelian tersimpan dan stok bertambah.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString().replaceFirst('Exception: ',''))));}}@override Widget build(BuildContext c)=>Column(children:[Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:Text('Pembelian Stok',style:Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w900))),FilledButton.icon(onPressed:save,icon:const Icon(Icons.save),label:const Text('Simpan'))])),Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:TextField(controller:supplier,decoration:const InputDecoration(labelText:'Supplier'))),Expanded(child:ListView.builder(padding:const EdgeInsets.all(12),itemCount:products.length,itemBuilder:(c,i){final x=products[i];final q=cart[x['id']]??0;return Card(child:ListTile(title:Text(x['name']),subtitle:Text('Harga beli ${money(x['buy_price'])} • stok ${x['stock']}'),trailing:SizedBox(width:150,child:Row(mainAxisAlignment:MainAxisAlignment.end,children:[IconButton(onPressed:()=>setState(()=>cart[x['id']]=q>0?q-1:0),icon:const Icon(Icons.remove)),Text('$q'),IconButton(onPressed:()=>setState(()=>cart[x['id']]=q+1),icon:const Icon(Icons.add))])));})]);}}

