import 'package:path/path.dart' as path;
import 'package:sqflite/sqflite.dart';

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();

  Database? _db;
  bool get isReady => _db != null && _db!.isOpen;
  Database get db {
    final value = _db;
    if (value == null || !value.isOpen) {
      throw StateError('Database KOMPRISMA belum diinisialisasi.');
    }
    return value;
  }

  Future<void> init() async {
    if (isReady) return;
    final databasePath = path.join(await getDatabasesPath(), 'komprisma_v3.db');
    _db = await openDatabase(
      databasePath,
      version: 6,
      onCreate: (database, version) async {
        await _schema(database);
        await _seed(database);
      },
      onUpgrade: (database, oldVersion, newVersion) async {
        await _migrate(database, oldVersion, newVersion);
      },
    );
  }

  Future<void> close() async {
    final database = _db;
    _db = null;
    if (database != null && database.isOpen) await database.close();
  }

  Future<void> _schema(DatabaseExecutor d) async {
    await d.execute('''CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Umum',
      sku TEXT NOT NULL UNIQUE,
      buy_price REAL NOT NULL DEFAULT 0,
      price REAL NOT NULL DEFAULT 0,
      stock INTEGER NOT NULL DEFAULT 0,
      min_stock INTEGER NOT NULL DEFAULT 3,
      unit TEXT NOT NULL DEFAULT 'pcs',
      active INTEGER NOT NULL DEFAULT 1
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS sales(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice TEXT NOT NULL UNIQUE,
      total REAL NOT NULL,
      subtotal REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0,
      tax REAL NOT NULL DEFAULT 0,
      received REAL NOT NULL DEFAULT 0,
      payment_method TEXT NOT NULL DEFAULT 'Tunai',
      customer_id INTEGER,
      cashier TEXT NOT NULL DEFAULT 'Administrator',
      created_at TEXT NOT NULL
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS sale_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      qty INTEGER NOT NULL,
      price REAL NOT NULL,
      buy_price REAL NOT NULL DEFAULT 0,
      discount REAL NOT NULL DEFAULT 0
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS stock_movements(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      type TEXT NOT NULL,
      qty INTEGER NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS store_settings(
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL DEFAULT ''
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'Kasir',
      pin TEXT,
      active INTEGER NOT NULL DEFAULT 1
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS customers(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      address TEXT,
      notes TEXT,
      active INTEGER NOT NULL DEFAULT 1
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS expenses(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'Operasional',
      amount REAL NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS purchases(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice TEXT NOT NULL UNIQUE,
      total REAL NOT NULL,
      supplier TEXT NOT NULL,
      note TEXT,
      created_at TEXT NOT NULL
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS purchase_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      qty INTEGER NOT NULL,
      cost REAL NOT NULL
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS audit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      detail TEXT,
      user_name TEXT NOT NULL DEFAULT 'Administrator',
      created_at TEXT NOT NULL
    )''');
    await d.execute('''CREATE TABLE IF NOT EXISTS cash_sessions(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      opening REAL NOT NULL DEFAULT 0,
      closing REAL,
      opened_at TEXT NOT NULL,
      closed_at TEXT,
      status TEXT NOT NULL DEFAULT 'OPEN'
    )''');

    await d.execute('CREATE INDEX IF NOT EXISTS idx_products_active_name ON products(active, name)');
    await d.execute('CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)');
    await d.execute('CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)');
    await d.execute('CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id)');
    await d.execute('CREATE INDEX IF NOT EXISTS idx_stock_movements_product ON stock_movements(product_id)');
    await d.execute('CREATE INDEX IF NOT EXISTS idx_expenses_created_at ON expenses(created_at)');
    await d.execute('CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log(created_at)');
  }

  Future<void> _migrate(DatabaseExecutor d, int oldVersion, int newVersion) async {
    // Existing V3 databases are kept intact. CREATE IF NOT EXISTS makes the
    // migration safe for databases produced by earlier BUILDs.
    await _schema(d);
    if (oldVersion < 6) {
      await d.execute('CREATE INDEX IF NOT EXISTS idx_sales_payment ON sales(payment_method)');
    }
  }

  Future<void> _seed(DatabaseExecutor d) async {
    final count = Sqflite.firstIntValue(await d.rawQuery('SELECT COUNT(*) FROM products')) ?? 0;
    if (count == 0) {
      await d.insert('products', {
        'name': 'Sofa Milano',
        'category': 'Furniture',
        'sku': 'SOF-001',
        'buy_price': 2200000,
        'price': 2850000,
        'stock': 10,
        'min_stock': 3,
        'unit': 'pcs',
      });
      await d.insert('products', {
        'name': 'Meja Minimalis',
        'category': 'Furniture',
        'sku': 'MEJ-001',
        'buy_price': 900000,
        'price': 1250000,
        'stock': 8,
        'min_stock': 3,
        'unit': 'pcs',
      });
      await d.insert('products', {
        'name': 'Lampu Modern',
        'category': 'Dekorasi',
        'sku': 'LAM-001',
        'buy_price': 300000,
        'price': 450000,
        'stock': 15,
        'min_stock': 3,
        'unit': 'pcs',
      });
    }

    final defaults = <String, String>{
      'store_name': 'KOMPRISMA STORE',
      'address': '',
      'phone': '',
      'receipt_footer': 'Terima kasih atas kunjungan Anda.',
      'tax_percent': '0',
      'currency': 'Rp',
      'printer_size': '58 mm',
      'theme': 'Sistem',
      'receipt_auto': '0',
    };
    for (final entry in defaults.entries) {
      await d.insert(
        'store_settings',
        {'key': entry.key, 'value': entry.value},
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }

    final users = Sqflite.firstIntValue(await d.rawQuery('SELECT COUNT(*) FROM users')) ?? 0;
    if (users == 0) {
      await d.insert('users', {
        'name': 'Administrator',
        'role': 'Admin',
        'pin': '',
        'active': 1,
      });
    }
  }

  Future<List<Map<String, dynamic>>> products([
    String q = '',
    String category = 'Semua',
  ]) async {
    final where = <String>['active = 1'];
    final args = <dynamic>[];
    if (q.trim().isNotEmpty) {
      where.add('(name LIKE ? OR sku LIKE ? OR category LIKE ?)');
      args.addAll(['%$q%', '%$q%', '%$q%']);
    }
    if (category != 'Semua') {
      where.add('category = ?');
      args.add(category);
    }
    return db.query(
      'products',
      where: where.join(' AND '),
      whereArgs: args,
      orderBy: 'name COLLATE NOCASE ASC',
    );
  }

  Future<List<Map<String, dynamic>>> allProducts({bool activeOnly = false}) =>
      db.query('products', where: activeOnly ? 'active = 1' : null, orderBy: 'name COLLATE NOCASE ASC');

  Future<List<String>> categories() async {
    final rows = await db.rawQuery(
      "SELECT DISTINCT category FROM products WHERE active=1 AND TRIM(category)<>'' ORDER BY category COLLATE NOCASE",
    );
    return ['Semua', ...rows.map((row) => row['category'].toString())];
  }

  Future<void> upsertProduct(Map<String, dynamic> product) async {
    final data = Map<String, dynamic>.from(product)..remove('id');
    final name = (data['name'] ?? '').toString().trim();
    final sku = (data['sku'] ?? '').toString().trim();
    final buy = (data['buy_price'] as num?)?.toDouble() ?? 0;
    final price = (data['price'] as num?)?.toDouble() ?? 0;
    final stock = (data['stock'] as num?)?.toInt() ?? 0;
    final minStock = (data['min_stock'] as num?)?.toInt() ?? 3;
    if (name.isEmpty) throw ArgumentError('Nama produk wajib diisi.');
    if (sku.isEmpty) throw ArgumentError('SKU / barcode wajib diisi.');
    if (buy < 0 || price < 0 || stock < 0 || minStock < 0) {
      throw ArgumentError('Harga dan stok tidak boleh bernilai negatif.');
    }
    data['name'] = name;
    data['sku'] = sku;
    data['buy_price'] = buy;
    data['price'] = price;
    data['stock'] = stock;
    data['min_stock'] = minStock;
    data['category'] = ((data['category'] ?? 'Umum').toString().trim().isEmpty)
        ? 'Umum'
        : data['category'].toString().trim();
    data['unit'] = ((data['unit'] ?? 'pcs').toString().trim().isEmpty)
        ? 'pcs'
        : data['unit'].toString().trim();

    final id = product['id'];
    if (id == null) {
      await db.insert('products', data);
      await log('PRODUK_DIBUAT', name);
    } else {
      await db.update('products', data, where: 'id = ?', whereArgs: [id]);
      await log('PRODUK_DIUBAH', name);
    }
  }

  Future<void> deleteProduct(int id) async {
    await db.update('products', {'active': 0}, where: 'id = ?', whereArgs: [id]);
    await log('PRODUK_DIARSIPKAN', 'ID produk $id');
  }

  Future<void> adjustStock(int id, int delta, String note) async {
    if (delta == 0) return;
    await db.transaction((tx) async {
      final rows = await tx.query('products', columns: ['stock', 'name'], where: 'id = ?', whereArgs: [id]);
      if (rows.isEmpty) throw StateError('Produk tidak ditemukan.');
      final current = (rows.first['stock'] as num).toInt();
      if (current + delta < 0) throw StateError('Stok tidak boleh minus.');
      await tx.update('products', {'stock': current + delta}, where: 'id = ?', whereArgs: [id]);
      await tx.insert('stock_movements', {
        'product_id': id,
        'type': delta > 0 ? 'MASUK' : 'KELUAR',
        'qty': delta.abs(),
        'note': note.trim().isEmpty ? 'Penyesuaian manual' : note.trim(),
        'created_at': DateTime.now().toIso8601String(),
      });
    });
  }

  Future<String> sale(
    Map<int, int> cart,
    num subtotal,
    num discount,
    num tax,
    num total,
    num received,
    String payment, {
    int? customerId,
    String cashier = 'Administrator',
  }) async {
    if (cart.isEmpty) throw ArgumentError('Keranjang masih kosong.');
    if (subtotal < 0 || discount < 0 || tax < 0 || total < 0 || received < 0) {
      throw ArgumentError('Nilai transaksi tidak valid.');
    }
    if (discount > subtotal) throw ArgumentError('Diskon melebihi subtotal.');
    if (received < total) throw ArgumentError('Uang diterima kurang dari total transaksi.');

    final normalizedPayment = payment.trim().isEmpty ? 'Tunai' : payment.trim();
    return db.transaction((tx) async {
      for (final entry in cart.entries) {
        if (entry.value <= 0) throw ArgumentError('Jumlah produk harus lebih dari 0.');
        final rows = await tx.query(
          'products',
          where: 'id = ? AND active = 1',
          whereArgs: [entry.key],
        );
        if (rows.isEmpty) throw StateError('Produk tidak ditemukan.');
        final stock = (rows.first['stock'] as num).toInt();
        if (stock < entry.value) throw StateError('Stok tidak cukup: ${rows.first['name']}');
      }

      final now = DateTime.now();
      final invoice = 'INV-${DateFormatHelper.invoice(now)}';
      final saleId = await tx.insert('sales', {
        'invoice': invoice,
        'subtotal': subtotal,
        'discount': discount,
        'tax': tax,
        'total': total,
        'received': received,
        'payment_method': normalizedPayment,
        'customer_id': customerId,
        'cashier': cashier.trim().isEmpty ? 'Administrator' : cashier.trim(),
        'created_at': now.toIso8601String(),
      });

      for (final entry in cart.entries) {
        final product = (await tx.query('products', where: 'id = ?', whereArgs: [entry.key])).first;
        await tx.insert('sale_items', {
          'sale_id': saleId,
          'product_id': entry.key,
          'qty': entry.value,
          'price': product['price'],
          'buy_price': product['buy_price'] ?? 0,
          'discount': 0,
        });
        await tx.rawUpdate('UPDATE products SET stock = stock - ? WHERE id = ?', [entry.value, entry.key]);
        await tx.insert('stock_movements', {
          'product_id': entry.key,
          'type': 'PENJUALAN',
          'qty': entry.value,
          'note': invoice,
          'created_at': now.toIso8601String(),
        });
      }
      return invoice;
    });
  }

  Future<List<Map<String, dynamic>>> sales({String range = 'Hari Ini', String q = ''}) async {
    String? where;
    final args = <dynamic>[];
    if (range == 'Hari Ini') {
      where = "date(created_at)=date('now','localtime')";
    } else if (range == '7 Hari') {
      where = "datetime(created_at)>=datetime('now','-7 days','localtime')";
    } else if (range == 'Bulan Ini') {
      where = "strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime')";
    }
    if (q.trim().isNotEmpty) {
      final search = '(invoice LIKE ? OR payment_method LIKE ? OR cashier LIKE ?)';
      where = where == null ? search : '$where AND $search';
      args.addAll(['%$q%', '%$q%', '%$q%']);
    }
    return db.query('sales', where: where, whereArgs: args.isEmpty ? null : args, orderBy: 'id DESC', limit: 500);
  }

  Future<List<Map<String, dynamic>>> saleItems(int id) => db.rawQuery(
        'SELECT si.*,p.name,p.unit FROM sale_items si LEFT JOIN products p ON p.id=si.product_id WHERE si.sale_id=? ORDER BY si.id',
        [id],
      );

  Future<List<Map<String, dynamic>>> stockHistory(int id) => db.query(
        'stock_movements',
        where: 'product_id = ?',
        whereArgs: [id],
        orderBy: 'id DESC',
        limit: 200,
      );

  Future<List<Map<String, dynamic>>> lowStock() => db.query(
        'products',
        where: 'active=1 AND stock<=min_stock',
        orderBy: 'stock ASC, name COLLATE NOCASE ASC',
      );

  Future<Map<String, dynamic>> dashboard() async {
    final productCount = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE active=1')) ?? 0;
    final transactionCount = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM sales WHERE date(created_at)=date('now','localtime')")) ?? 0;
    final omzet = await db.rawQuery("SELECT COALESCE(SUM(total),0) AS value FROM sales WHERE date(created_at)=date('now','localtime')");
    final profit = await db.rawQuery("SELECT COALESCE(SUM((si.price-si.buy_price)*si.qty),0) AS value FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)=date('now','localtime')");
    final expense = await db.rawQuery("SELECT COALESCE(SUM(amount),0) AS value FROM expenses WHERE date(created_at)=date('now','localtime')");
    final low = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE active=1 AND stock<=min_stock')) ?? 0;
    final stockValue = await db.rawQuery('SELECT COALESCE(SUM(stock*buy_price),0) AS value FROM products WHERE active=1');
    return {
      'products': productCount,
      'transactions': transactionCount,
      'omzet': omzet.first['value'] ?? 0,
      'profit': profit.first['value'] ?? 0,
      'expense': expense.first['value'] ?? 0,
      'lowStock': low,
      'stockValue': stockValue.first['value'] ?? 0,
    };
  }

  Future<Map<String, String>> settings() async {
    final rows = await db.query('store_settings');
    return {for (final row in rows) row['key'].toString(): (row['value'] ?? '').toString()};
  }

  Future<void> setSettings(Map<String, String> values) async {
    await db.transaction((tx) async {
      for (final entry in values.entries) {
        await tx.insert(
          'store_settings',
          {'key': entry.key, 'value': entry.value},
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
    await log('PENGATURAN_DIUBAH', values.keys.join(', '));
  }

  Future<List<Map<String, dynamic>>> users() => db.query('users', where: 'active=1', orderBy: 'id');

  Future<void> saveUser(Map<String, dynamic> user) async {
    final name = (user['name'] ?? '').toString().trim();
    if (name.isEmpty) throw ArgumentError('Nama pengguna wajib diisi.');
    final role = (user['role'] ?? 'Kasir').toString();
    if (!['Admin', 'Kasir', 'Supervisor'].contains(role)) throw ArgumentError('Role pengguna tidak valid.');
    final pin = (user['pin'] ?? '').toString().trim();
    if (pin.isNotEmpty && !RegExp(r'^\d{4,6}$').hasMatch(pin)) {
      throw ArgumentError('PIN harus berupa 4-6 digit angka.');
    }
    final data = <String, dynamic>{'name': name, 'role': role, 'pin': pin, 'active': 1};
    if (user['id'] == null) {
      await db.insert('users', data);
      await log('PENGGUNA_DIBUAT', name);
    } else {
      await db.update('users', data, where: 'id=?', whereArgs: [user['id']]);
      await log('PENGGUNA_DIUBAH', name);
    }
  }

  Future<void> deleteUser(int id) async {
    final adminCount = Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM users WHERE active=1 AND role='Admin'")) ?? 0;
    final target = await db.query('users', columns: ['role', 'name'], where: 'id=? AND active=1', whereArgs: [id], limit: 1);
    if (target.isEmpty) return;
    if (target.first['role'] == 'Admin' && adminCount <= 1) throw StateError('Minimal harus ada satu Admin aktif.');
    await db.update('users', {'active': 0}, where: 'id=?', whereArgs: [id]);
    await log('PENGGUNA_DIARSIPKAN', target.first['name'].toString());
  }

  Future<List<Map<String, dynamic>>> customers() => db.query('customers', where: 'active=1', orderBy: 'name COLLATE NOCASE');

  Future<void> saveCustomer(Map<String, dynamic> customer) async {
    final name = (customer['name'] ?? '').toString().trim();
    if (name.isEmpty) throw ArgumentError('Nama pelanggan wajib diisi.');
    final data = Map<String, dynamic>.from(customer)
      ..remove('id')
      ..['name'] = name;
    if (customer['id'] == null) {
      await db.insert('customers', data);
      await log('PELANGGAN_DIBUAT', name);
    } else {
      await db.update('customers', data, where: 'id=?', whereArgs: [customer['id']]);
      await log('PELANGGAN_DIUBAH', name);
    }
  }

  Future<void> deleteCustomer(int id) async {
    await db.update('customers', {'active': 0}, where: 'id=?', whereArgs: [id]);
    await log('PELANGGAN_DIARSIPKAN', 'ID pelanggan $id');
  }

  Future<List<Map<String, dynamic>>> expenses({String range = 'Hari Ini'}) async {
    String? where;
    if (range == 'Hari Ini') where = "date(created_at)=date('now','localtime')";
    if (range == 'Bulan Ini') where = "strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime')";
    return db.query('expenses', where: where, orderBy: 'id DESC', limit: 500);
  }

  Future<void> addExpense(String title, String category, num amount, String note) async {
    final cleanTitle = title.trim();
    if (cleanTitle.isEmpty) throw ArgumentError('Nama biaya wajib diisi.');
    if (amount <= 0) throw ArgumentError('Nominal biaya harus lebih dari 0.');
    await db.insert('expenses', {
      'title': cleanTitle,
      'category': category.trim().isEmpty ? 'Operasional' : category.trim(),
      'amount': amount,
      'note': note.trim(),
      'created_at': DateTime.now().toIso8601String(),
    });
    await log('BIAYA_DICATAT', cleanTitle);
  }

  Future<List<Map<String, dynamic>>> movementLog() => db.rawQuery(
        'SELECT sm.*,p.name FROM stock_movements sm LEFT JOIN products p ON p.id=sm.product_id ORDER BY sm.id DESC LIMIT 500',
      );

  Future<List<Map<String, dynamic>>> audit() => db.query('audit_log', orderBy: 'id DESC', limit: 300);

  Future<void> log(String action, String detail, {String user = 'Administrator'}) async {
    if (!isReady) return;
    await db.insert('audit_log', {
      'action': action,
      'detail': detail,
      'user_name': user,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> addPurchase(String supplier, Map<int, int> items) async {
    final cleanSupplier = supplier.trim();
    if (cleanSupplier.isEmpty) throw ArgumentError('Nama supplier wajib diisi.');
    final validItems = items.entries.where((entry) => entry.value > 0).toList();
    if (validItems.isEmpty) throw ArgumentError('Belum ada produk yang dipilih.');

    await db.transaction((tx) async {
      final now = DateTime.now();
      final invoice = 'PO-${DateFormatHelper.invoice(now)}';
      num total = 0;
      final resolved = <Map<String, dynamic>>[];

      for (final entry in validItems) {
        final rows = await tx.query('products', where: 'id=? AND active=1', whereArgs: [entry.key], limit: 1);
        if (rows.isEmpty) throw StateError('Produk pembelian tidak ditemukan.');
        final cost = (rows.first['buy_price'] as num?) ?? 0;
        total += cost * entry.value;
        resolved.add({'product': rows.first, 'qty': entry.value, 'cost': cost});
      }

      final purchaseId = await tx.insert('purchases', {
        'invoice': invoice,
        'total': total,
        'supplier': cleanSupplier,
        'note': 'Pembelian stok',
        'created_at': now.toIso8601String(),
      });

      for (final item in resolved) {
        final product = item['product'] as Map<String, dynamic>;
        final qty = item['qty'] as int;
        final cost = item['cost'] as num;
        final productId = product['id'] as int;
        await tx.insert('purchase_items', {
          'purchase_id': purchaseId,
          'product_id': productId,
          'qty': qty,
          'cost': cost,
        });
        await tx.rawUpdate('UPDATE products SET stock=stock+? WHERE id=?', [qty, productId]);
        await tx.insert('stock_movements', {
          'product_id': productId,
          'type': 'PEMBELIAN',
          'qty': qty,
          'note': invoice,
          'created_at': now.toIso8601String(),
        });
      }
    });
    await log('PEMBELIAN_DICATAT', 'Supplier: $cleanSupplier');
  }
}

class DateFormatHelper {
  static String invoice(DateTime d) =>
      '${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}-'
      '${d.hour.toString().padLeft(2, '0')}${d.minute.toString().padLeft(2, '0')}'
      '${d.second.toString().padLeft(2, '0')}${d.millisecond.toString().padLeft(3, '0')}';
}
