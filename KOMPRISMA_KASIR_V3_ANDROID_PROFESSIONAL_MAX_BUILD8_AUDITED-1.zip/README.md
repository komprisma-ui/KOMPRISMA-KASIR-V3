# KOMPRISMA KASIR V3 Professional

**KOMPRISMA KASIR — POS offline-first untuk Android.**

## Modul yang tersedia

- Dashboard: omzet, transaksi, laba kotor, biaya, stok menipis dan nilai persediaan.
- Kasir: pencarian produk, kategori, keranjang, barcode kamera, diskon, pajak, pembayaran Tunai/Transfer/QRIS/Debit.
- Produk & Stok: tambah, edit, arsip, penyesuaian stok dan batas stok minimum.
- Transaksi: riwayat, filter periode, pencarian, detail dan export CSV.
- Pembelian Stok: supplier, item pembelian dan penambahan stok atomik.
- Mutasi Stok: riwayat seluruh pergerakan stok.
- Pelanggan: data pelanggan dan arsip.
- Biaya Operasional: pencatatan biaya dan filter periode.
- Laporan: ringkasan operasional dan indikator laba bersih.
- Admin & Kasir: pengguna, role, PIN dan perlindungan agar Admin terakhir tidak terhapus.
- Audit Trail: aktivitas penting tersimpan di database lokal.
- Pengaturan: identitas toko, struk/printer, pajak, barcode, backup, preferensi dan tentang aplikasi.

## Data dan keamanan dasar

- SQLite lokal/offline.
- Database versioned dan migrasi aman untuk build sebelumnya.
- Transaksi penjualan dan pembelian menggunakan database transaction.
- Stok tidak boleh menjadi negatif.
- Validasi harga, stok, diskon, pembayaran, PIN dan data wajib.
- Backup database dapat dibagikan melalui Android share sheet.

## Build GitHub Actions

Workflow `.github/workflows/android-apk.yml` akan:

1. checkout source;
2. memasang Flutter 3.24.5 stable;
3. membuat folder Android otomatis hanya bila belum tersedia;
4. menjalankan `flutter pub get`;
5. memeriksa formatting;
6. menjalankan `flutter analyze`;
7. menjalankan `flutter test`;
8. menjalankan `flutter build apk --release`;
9. memverifikasi file APK;
10. mengunggah APK sebagai artifact.

Workflow berjalan pada push ke `main`, tag `v*`, atau manual melalui **Run workflow**.

> Build ini menghasilkan APK release yang siap diuji. Signing/keystore produksi sebaiknya ditambahkan sebagai GitHub Secrets ketika aplikasi akan didistribusikan secara resmi.
