import 'package:flutter_test/flutter_test.dart';
import 'package:komprisma_kasir_v3/main.dart';

void main() {
  group('format and input helpers', () {
    test('nval handles Indonesian thousands separators', () {
      expect(nval('1.500.000'), 1500000);
      expect(nval('Rp 2.500.000'), 2500000);
      expect(nval('12,5'), 12.5);
      expect(nval('1.234,50'), 1234.5);
      expect(nval('1,234.50'), 1234.5);
    });

    test('nval safely handles empty and invalid input', () {
      expect(nval(''), 0);
      expect(nval('abc'), 0);
      expect(nval('-25.000'), -25000);
    });
  });
}
