#!/usr/bin/env bash
set -euo pipefail

required=(
  pubspec.yaml
  lib/main.dart
  lib/db.dart
  test/widget_test.dart
  test/core_test.dart
  .github/workflows/android-apk.yml
)
for file in "${required[@]}"; do
  test -f "$file" || { echo "Missing required file: $file"; exit 1; }
done

grep -q "Future<void> preferences(BuildContext context)" lib/main.dart
grep -q "Future<void> about(BuildContext context)" lib/main.dart
grep -q "flutter build apk --release" .github/workflows/android-apk.yml
grep -q "flutter analyze" .github/workflows/android-apk.yml
grep -q "flutter test" .github/workflows/android-apk.yml
! grep -q "PlaceholderPage" lib/main.dart
! grep -q "|| true" .github/workflows/android-apk.yml

echo "KOMPRISMA preflight checks: PASS"
