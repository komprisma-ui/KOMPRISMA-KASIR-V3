import 'package:flutter/material.dart';
import 'db.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.init();
  runApp(const KomprismaApp());
}

class KomprismaApp extends StatelessWidget {
  const KomprismaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'KOMPRISMA KASIR V3',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFFB88A2B),
      scaffoldBackgroundColor: const Color(0xFFF7F5F0)),
    home: const Home(),
  );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override State<Home> createState()=>_HomeState();
}
class _HomeState extends State<Home>{
  int index=0;
  final pages=const [Dashboard(), Pos(), Products(), Sales(), Settings()];
  @override Widget build(BuildContext c)=>Scaffold(
    appBar: AppBar(title: const Text('KOMPRISMA KASIR V3',
      style: TextStyle(fontWeight: FontWeight.w900))),
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),label:'Beranda'),
        NavigationDestination(icon:Icon(Icons.point_of_sale_outlined),label:'Kasir'),
        NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'Produk'),
        NavigationDestination(icon:Icon(Icons.receipt_long_outlined),label:'Transaksi'),
        NavigationDestination(icon:Icon(Icons.settings_outlined),label:'Pengaturan'),
      ]),
  );
}

class Dashboard extends StatelessWidget{
  const Dashboard({super.key});
  @override Widget build(BuildContext c)=>FutureBuilder(
    future:AppDb.instance.dashboard(),builder:(c,s){
      final d=s.data??{};
      return ListView(padding:const EdgeInsets.all(16),children:[
        const Text('Ringkasan Hari Ini',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),
        const SizedBox(height:14),
        Wrap(spacing:12,runSpacing:12,children:[
          Stat('Omzet',money(d['omzet']??0),Icons.payments_outlined),
          Stat('Transaksi','${d['transactions']??0}',Icons.receipt_long_outlined),
          Stat('Produk','${d['products']??0}',Icons.inventory_2_outlined),
          Stat('Stok Menipis','${d['lowStock']??0}',Icons.warning_amber_outlined),
        ]),
        const SizedBox(height:18),
        Card(child:ListTile(leading:const Icon(Icons.cloud_off_outlined),
          title:const Text('Mode Offline Aktif',style:TextStyle(fontWeight:FontWeight.w800)),
          subtitle:const Text('Data transaksi tersimpan di perangkat.'))),
      ]);
    });
}
class Stat extends StatelessWidget{
  final String a,b; final IconData icon;
  const Stat(this.a,this.b,this.icon,{super.key});
  @override Widget build(BuildContext c)=>SizedBox(width:220,child:Card(
    child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,
      children:[Icon(icon,size:28),const SizedBox(height:15),Text(a),Text(b,
        style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900))]))));
}

class Pos extends StatefulWidget{const Pos({super.key});@override State<Pos> createState()=>_PosState();}
class _PosState extends State<Pos>{
  List<Map<String,dynamic>> products=[]; final Map<int,int> cart={}; String q='';
  @override void initState(){super.initState();load();}
  Future<void> load()async{products=await AppDb.instance.products(q);if(mounted)setState((){});}
  num total()=>cart.entries.fold(0,(s,e){
    final p=products.firstWhere((x)=>x['id']==e.key,orElse:()=>{});
    return s+(p['price']??0)*e.value;
  });
  @override Widget build(BuildContext c)=>Column(children:[
    Padding(padding:const EdgeInsets.all(12),child:TextField(
      decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Cari nama / SKU',
        border:OutlineInputBorder()),onChanged:(v){q=v;load();})),
    Expanded(child:LayoutBuilder(builder:(c,con){
      final grid=GridView.builder(padding:const EdgeInsets.all(12),
        gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:con.maxWidth>800?3:2,
          crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.45),itemCount:products.length,
        itemBuilder:(c,i){final p=products[i];return Card(child:InkWell(onTap:()=>setState((){
          final id=p['id'] as int; final n=(cart[id]??0)+1;
          if(n<=(p['stock'] as int))cart[id]=n;
        }),child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,
          children:[Text(p['name'],maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w800)),
            const Spacer(),Text(money(p['price']),style:const TextStyle(fontWeight:FontWeight.w800)),
            Text('Stok ${p['stock']}')]))));});
      return con.maxWidth>800?Row(children:[
        Expanded(child:grid),SizedBox(width:310,child:Cart(cart:cart,products:products,total:total(),changed:()=>setState((){}),pay:checkout))
      ]):grid;
    })),
    if(MediaQuery.of(c).size.width<=800)SafeArea(child:Padding(padding:const EdgeInsets.all(12),
      child:FilledButton.icon(onPressed:cart.isEmpty?null:checkout,icon:const Icon(Icons.payments),
        label:Text('Bayar • ${money(total())}'))))
  ]);
  Future<void> checkout()async{
    final ctl=TextEditingController(text:total().toStringAsFixed(0));
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Pembayaran Tunai'),
      content:TextField(controller:ctl,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Uang diterima')),
      actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Batal')),
        FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Simpan'))]));
    if(ok!=true)return;
    final received=num.tryParse(ctl.text.replaceAll(RegExp(r'[^0-9]'),''))??0, amount=total();
    if(received<amount){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Uang diterima kurang.')));return;}
    try{await AppDb.instance.sale(cart,amount,received);cart.clear();await load();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Tersimpan • Kembalian ${money(received-amount)}')));
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }
}
class Cart extends StatelessWidget{
  final Map<int,int> cart;final List<Map<String,dynamic>> products;final num total;final VoidCallback changed,pay;
  const Cart({super.key,required this.cart,required this.products,required this.total,required this.changed,required this.pay});
  @override Widget build(BuildContext c)=>Card(margin:const EdgeInsets.all(12),child:Padding(padding:const EdgeInsets.all(14),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Keranjang',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const Divider(),
      Expanded(child:ListView(children:cart.entries.map((e){final p=products.firstWhere((x)=>x['id']==e.key,orElse:()=>{});
        return ListTile(title:Text(p['name']??''),subtitle:Text('${e.value} × ${money(p['price']??0)}'),
          trailing:IconButton(icon:const Icon(Icons.remove_circle_outline),onPressed:(){if(e.value<=1)cart.remove(e.key);else cart[e.key]=e.value-1;changed();}));
      }).toList())),Text('TOTAL ${money(total)}',style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900)),
      const SizedBox(height:8),FilledButton.icon(onPressed:cart.isEmpty?null:pay,icon:const Icon(Icons.payments),label:const Text('Bayar'))
    ])));
}

class Products extends StatefulWidget{const Products({super.key});@override State<Products> createState()=>_ProductsState();}
class _ProductsState extends State<Products>{
  List<Map<String,dynamic>> data=[];
  @override void initState(){super.initState();load();}
  Future<void>load()async{data=await AppDb.instance.products();if(mounted)setState((){});}
  @override Widget build(BuildContext c)=>Scaffold(backgroundColor:Colors.transparent,
    floatingActionButton:FloatingActionButton.extended(onPressed:()=>edit(),icon:const Icon(Icons.add),label:const Text('Produk')),
    body:ListView(padding:const EdgeInsets.all(12),children:data.map((p)=>Card(child:ListTile(
      title:Text(p['name'],style:const TextStyle(fontWeight:FontWeight.w800)),
      subtitle:Text('${p['category']} • SKU ${p['sku']} • Stok ${p['stock']}'),
      trailing:Text(money(p['price']),style:const TextStyle(fontWeight:FontWeight.w800)),onTap:()=>edit(p)))).toList()));
  Future<void>edit([Map<String,dynamic>? p])async{
    final n=TextEditingController(text:p?['name']??''),cat=TextEditingController(text:p?['category']??'Umum'),
      sku=TextEditingController(text:p?['sku']??''),price=TextEditingController(text:'${p?['price']??0}'),
      stock=TextEditingController(text:'${p?['stock']??0}');
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(p==null?'Tambah Produk':'Edit Produk'),
      content:SingleChildScrollView(child:Column(children:[
        TextField(controller:n,decoration:const InputDecoration(labelText:'Nama')),
        TextField(controller:cat,decoration:const InputDecoration(labelText:'Kategori')),
        TextField(controller:sku,decoration:const InputDecoration(labelText:'SKU / Barcode')),
        TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Harga')),
        TextField(controller:stock,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stok')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Batal')),
        FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Simpan'))]));
    if(ok==true){await AppDb.instance.upsert({'id':p?['id'],'name':n.text.trim(),'category':cat.text.trim(),
      'sku':sku.text.trim(),'price':num.tryParse(price.text)??0,'stock':int.tryParse(stock.text)??0});await load();}
  }
}
class Sales extends StatelessWidget{const Sales({super.key});
  @override Widget build(BuildContext c)=>FutureBuilder(future:AppDb.instance.sales(),builder:(c,s)=>ListView(
    padding:const EdgeInsets.all(12),children:(s.data??[]).map((x)=>Card(child:ListTile(
      leading:const Icon(Icons.receipt_long),title:Text(x['invoice']),subtitle:Text(x['created_at']),
      trailing:Text(money(x['total']),style:const TextStyle(fontWeight:FontWeight.w800))))).toList()));}
class Settings extends StatelessWidget{const Settings({super.key});
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[
    Card(child:ListTile(leading:const Icon(Icons.store_outlined),title:const Text('Identitas Toko'),
      subtitle:const Text('Nama toko, alamat, kontak, footer struk'))),
    Card(child:ListTile(leading:const Icon(Icons.lock_outline),title:const Text('Admin & Kasir'),
      subtitle:const Text('Fondasi hak akses dan PIN pengguna'))),
    Card(child:ListTile(leading:const Icon(Icons.backup_outlined),title:const Text('Backup & Restore'),
      subtitle:const Text('Database lokal dan ekspor data'))),
    Card(child:ListTile(leading:const Icon(Icons.print_outlined),title:const Text('Printer Thermal'),
      subtitle:const Text('Fondasi integrasi printer Bluetooth / USB'))),
    Card(child:ListTile(leading:const Icon(Icons.qr_code_scanner),title:const Text('Barcode'),
      subtitle:const Text('Scanner kamera siap diintegrasikan'))),
  ]);}
String money(num v)=>'Rp ${v.toStringAsFixed(0).replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'),(m)=>'${m[1]}.')}';
