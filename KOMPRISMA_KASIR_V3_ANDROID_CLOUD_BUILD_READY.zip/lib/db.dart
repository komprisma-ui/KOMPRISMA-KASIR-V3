import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDb{
  AppDb._();static final instance=AppDb._();late Database db;
  Future<void>init()async{db=await openDatabase(join(await getDatabasesPath(),'komprisma_v3.db'),version:1,onCreate:(d,v)async{
    await d.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,sku TEXT UNIQUE,price REAL NOT NULL,stock INTEGER NOT NULL DEFAULT 0)');
    await d.execute('CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice TEXT,total REAL,received REAL,created_at TEXT)');
    await d.execute('CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,product_id INTEGER,qty INTEGER,price REAL)');
    await d.insert('products',{'name':'Sofa Milano','category':'Furniture','sku':'SOF-001','price':2850000,'stock':10});
    await d.insert('products',{'name':'Meja Minimalis','category':'Furniture','sku':'MEJ-001','price':1250000,'stock':8});
    await d.insert('products',{'name':'Lampu Modern','category':'Dekorasi','sku':'LAM-001','price':450000,'stock':15});
  });}
  Future<List<Map<String,dynamic>>>products([String q=''])async=>q.trim().isEmpty?db.query('products',orderBy:'name'):
    db.query('products',where:'name LIKE ? OR sku LIKE ? OR category LIKE ?',whereArgs:['%$q%','%$q%','%$q%'],orderBy:'name');
  Future<void>upsert(Map<String,dynamic>p)async{if(p['id']==null){final x=Map<String,dynamic>.from(p)..remove('id');await db.insert('products',x);}else await db.update('products',p,where:'id=?',whereArgs:[p['id']]);}
  Future<void>sale(Map<int,int>cart,num total,num received)async{await db.transaction((tx)async{
    for(final e in cart.entries){final r=await tx.query('products',where:'id=?',whereArgs:[e.key]);if(r.isEmpty)throw Exception('Produk tidak ditemukan');
      if((r.first['stock'] as int)<e.value)throw Exception('Stok tidak cukup: ${r.first['name']}');}
    final inv='INV-${DateTime.now().millisecondsSinceEpoch}',sid=await tx.insert('sales',
      {'invoice':inv,'total':total,'received':received,'created_at':DateTime.now().toIso8601String()});
    for(final e in cart.entries){final p=(await tx.query('products',where:'id=?',whereArgs:[e.key])).first;
      await tx.insert('sale_items',{'sale_id':sid,'product_id':e.key,'qty':e.value,'price':p['price']});
      await tx.rawUpdate('UPDATE products SET stock=stock-? WHERE id=?',[e.value,e.key]);}
  });}
  Future<List<Map<String,dynamic>>>sales()=>db.query('sales',orderBy:'id DESC',limit:100);
  Future<Map<String,dynamic>>dashboard()async{final p=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products'))??0;
    final t=Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM sales WHERE date(created_at)=date('now','localtime')"))??0;
    final o=await db.rawQuery("SELECT COALESCE(SUM(total),0) x FROM sales WHERE date(created_at)=date('now','localtime')");
    final l=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE stock<=3'))??0;
    return {'products':p,'transactions':t,'omzet':o.first['x']??0,'lowStock':l};}
}
