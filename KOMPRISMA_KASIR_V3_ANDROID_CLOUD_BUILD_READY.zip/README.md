# KOMPRISMA KASIR V3 ANDROID — FINAL SELLABLE BASE

Release: 3.0.0+1

## Included
- Offline-first SQLite database
- Dashboard
- POS / cart / cash checkout / change
- Product & stock management
- Stock validation
- Sales history
- Admin PIN / cashier role foundation
- Store settings
- Backup/export foundation
- Barcode scanning dependency ready
- PDF receipt/report dependency ready
- Responsive phone/tablet layout

## Build
flutter pub get
flutter analyze
flutter test
flutter build apk --release

## Product direction
The architecture is deliberately modular so Bluetooth/USB thermal printing, advanced reports,
cloud sync and licensing can be added without replacing the core database.

## Important
Before commercial release, run device testing on the target Android versions and test the exact
thermal printer models intended for customers.


## Cloud build
See `CLOUD_BUILD.md`. GitHub Actions workflow is included under `.github/workflows/`.
