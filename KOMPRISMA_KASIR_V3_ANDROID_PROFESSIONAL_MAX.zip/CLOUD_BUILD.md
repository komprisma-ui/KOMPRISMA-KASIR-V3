# KOMPRISMA KASIR V3 — CLOUD BUILD PACKAGE

Paket ini dibuat agar proyek dapat dibuild dari HP melalui layanan cloud CI/CD.

## Opsi paling mudah: GitHub Actions
1. Buat repository GitHub dari HP.
2. Upload seluruh isi paket ini ke repository.
3. Buka tab **Actions**.
4. Pilih **Build KOMPRISMA Android APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai selesai.
7. Buka hasil workflow dan ambil artifact `komprisma-kasir-v3-apk`.
8. Download APK dan install di Android.

Workflow otomatis:
- mengambil source
- memasang Flutter
- `flutter pub get`
- `flutter analyze`
- `flutter test`
- `flutter build apk --release`
- menyimpan APK sebagai artifact

## Catatan release
APK yang dihasilkan workflow ini adalah release APK yang dapat diuji di perangkat.
Untuk distribusi Google Play, siapkan signing key/keystore dan konfigurasi signing khusus
sebelum upload ke Play Console.

## Kualitas
Jangan menjual sebelum menguji:
- transaksi tunai
- stok dan stok minus
- restart aplikasi
- backup/restore
- scanner barcode
- printer thermal yang digunakan pelanggan
- berbagai ukuran layar Android

## Struktur
- `.github/workflows/android-apk.yml` = otomatisasi cloud build
- `lib/` = source aplikasi
- `pubspec.yaml` = dependency
- `test/` = smoke test
