import 'package:flutter_test/flutter_test.dart';
import 'package:komprisma_kasir_v3/main.dart';

void main() {
  testWidgets('KOMPRISMA app smoke test', (tester) async {
    await tester.pumpWidget(const KomprismaApp());
    expect(find.text('KOMPRISMA KASIR V3'), findsOneWidget);
    expect(find.text('Beranda'), findsOneWidget);
    expect(find.text('Kasir'), findsOneWidget);
  });
}
