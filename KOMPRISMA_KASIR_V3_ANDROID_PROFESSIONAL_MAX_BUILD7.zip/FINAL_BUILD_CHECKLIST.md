# KOMPRISMA KASIR V3 — BUILD 7 FINAL CHECKLIST

## Source hardening
- PDF receipt values are explicitly converted to strings/numbers.
- Mobile Scanner uses the `BarcodeCapture` callback API for mobile_scanner 5.2.3.
- Settings duplicate widget declarations removed.
- Product validation rejects negative price, cost, stock and minimum stock.
- Cash payment rejects insufficient payment.
- Stock, product, customer and user mutations write audit records.
- Database upgraded to schema version 6 with useful indexes.
- Backup and restore are available from Settings.
- Cart subtotal is calculated from the actual cart value.
- Release workflow selects **only** the exact BUILD7 ZIP, eliminating stale-ZIP builds.

## Release gate
1. `flutter pub get`
2. `flutter analyze --no-fatal-warnings --no-fatal-infos`
3. `flutter test`
4. `flutter build apk --release`
5. APK existence + SHA-256 verification

A build is not considered final until all five release gates pass.
