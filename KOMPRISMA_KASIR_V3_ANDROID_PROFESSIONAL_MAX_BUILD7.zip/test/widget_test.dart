import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:komprisma_kasir_v3/main.dart';

void main() {
  test('numeric parsing is safe', () {
    expect(nval('Rp 12.500'), 12500);
    expect(nval('invalid'), 0);
  });

  testWidgets('KOMPRISMA basic widgets render', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: Stat('Omzet', 'Rp 0', Icons.payments),
        ),
      ),
    );
    expect(find.text('Omzet'), findsOneWidget);
    expect(find.text('Rp 0'), findsOneWidget);
  });
}
