import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDb {
  AppDb._();
  static final instance = AppDb._();
  late Database db;

  Future<void> init() async {
    db = await openDatabase(
      await databasePath(),
      version: 6,
      onCreate: (d, v) async { await _schema(d); await _seed(d); },
      onUpgrade: (d, oldV, newV) async { await _migrate(d, oldV); },
    );
  }

  Future<void> _schema(DatabaseExecutor d) async {
    await d.execute('''CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT,sku TEXT UNIQUE,buy_price REAL NOT NULL DEFAULT 0,price REAL NOT NULL,stock INTEGER NOT NULL DEFAULT 0,min_stock INTEGER NOT NULL DEFAULT 3,unit TEXT NOT NULL DEFAULT 'pcs',active INTEGER NOT NULL DEFAULT 1)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice TEXT UNIQUE,total REAL NOT NULL,subtotal REAL NOT NULL DEFAULT 0,discount REAL NOT NULL DEFAULT 0,tax REAL NOT NULL DEFAULT 0,received REAL NOT NULL DEFAULT 0,payment_method TEXT NOT NULL DEFAULT 'Tunai',customer_id INTEGER,cashier TEXT,created_at TEXT)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,product_id INTEGER,qty INTEGER,price REAL,buy_price REAL DEFAULT 0,discount REAL DEFAULT 0)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,type TEXT,qty INTEGER,note TEXT,created_at TEXT)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS store_settings(key TEXT PRIMARY KEY,value TEXT)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,role TEXT NOT NULL,pin TEXT,active INTEGER NOT NULL DEFAULT 1)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,address TEXT,notes TEXT,active INTEGER NOT NULL DEFAULT 1)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,category TEXT,amount REAL NOT NULL,note TEXT,created_at TEXT)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice TEXT,total REAL NOT NULL,supplier TEXT,note TEXT,created_at TEXT)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER,product_id INTEGER,qty INTEGER,cost REAL)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT,detail TEXT,user_name TEXT,created_at TEXT)''');
    await d.execute('''CREATE TABLE IF NOT EXISTS cash_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,opening REAL DEFAULT 0,closing REAL,opened_at TEXT,closed_at TEXT,status TEXT DEFAULT 'OPEN')''');
  }

  Future<void> _migrate(DatabaseExecutor d, int oldV) async {
    await _schema(d);
    if (oldV < 3) {
      for (final sql in ["ALTER TABLE sales ADD COLUMN tax REAL NOT NULL DEFAULT 0","ALTER TABLE sales ADD COLUMN customer_id INTEGER","ALTER TABLE sales ADD COLUMN cashier TEXT","ALTER TABLE sale_items ADD COLUMN discount REAL DEFAULT 0"]) { try { await d.execute(sql); } catch (_) {} }
    }
    if (oldV < 4) { await _schema(d); }
    if (oldV < 5) { await _schema(d); }
    if (oldV < 6) {
      await d.execute('CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)');
      await d.execute('CREATE INDEX IF NOT EXISTS idx_sale_items_sale_id ON sale_items(sale_id)');
      await d.execute('CREATE INDEX IF NOT EXISTS idx_stock_movements_product_id ON stock_movements(product_id)');
    }
  }

  Future<void> checkpoint() async { await db.rawQuery('PRAGMA wal_checkpoint(FULL)'); }

  Future<String> databasePath() async => join(await getDatabasesPath(), 'komprisma_v3.db');

  Future<void> close() async { if (db.isOpen) await db.close(); }

  Future<void> _seed(DatabaseExecutor d) async {
    await d.insert('products', {'name':'Sofa Milano','category':'Furniture','sku':'SOF-001','buy_price':2200000,'price':2850000,'stock':10,'min_stock':3,'unit':'pcs'});
    await d.insert('products', {'name':'Meja Minimalis','category':'Furniture','sku':'MEJ-001','buy_price':900000,'price':1250000,'stock':8,'min_stock':3,'unit':'pcs'});
    await d.insert('products', {'name':'Lampu Modern','category':'Dekorasi','sku':'LAM-001','buy_price':300000,'price':450000,'stock':15,'min_stock':3,'unit':'pcs'});
    final defaults = {'store_name':'KOMPRISMA STORE','address':'','phone':'','receipt_footer':'Terima kasih atas kunjungan Anda.','tax_percent':'0','currency':'Rp','printer_size':'58 mm','theme':'Sistem','receipt_auto':'0'};
    for (final e in defaults.entries) await d.insert('store_settings', {'key':e.key,'value':e.value});
    await d.insert('users', {'name':'Administrator','role':'Admin','pin':'','active':1});
  }

  Future<List<Map<String,dynamic>>> products([String q='',String category='Semua']) async {
    final where=['active=1']; final args=<dynamic>[];
    if(q.trim().isNotEmpty){where.add('(name LIKE ? OR sku LIKE ? OR category LIKE ?)');args.addAll(['%$q%','%$q%','%$q%']);}
    if(category!='Semua'){where.add('category=?');args.add(category);}
    return db.query('products',where:where.join(' AND '),whereArgs:args,orderBy:'name');
  }
  Future<List<Map<String,dynamic>>> allProducts({bool activeOnly=false})=>db.query('products',where:activeOnly?'active=1':null,orderBy:'name');
  Future<List<String>> categories() async {final r=await db.rawQuery("SELECT DISTINCT category FROM products WHERE active=1 AND category IS NOT NULL AND TRIM(category)<>'' ORDER BY category");return ['Semua',...r.map((e)=>e['category'].toString())];}
  Future<void> upsertProduct(Map<String,dynamic> p) async {final d=Map<String,dynamic>.from(p)..remove('id');if(p['id']==null){await db.insert('products',d);await log('PRODUK_DIBUAT',p['name']?.toString()??'');}else{await db.update('products',d,where:'id=?',whereArgs:[p['id']]);await log('PRODUK_DIUBAH',p['name']?.toString()??'');}}
  Future<void> deleteProduct(int id)async{await db.update('products',{'active':0},where:'id=?',whereArgs:[id]);await log('PRODUK_DIARSIPKAN','ID $id');}
  Future<void> adjustStock(int id,int delta,String note) async {await db.transaction((tx) async {final r=await tx.query('products',columns:['stock','name'],where:'id=?',whereArgs:[id]);if(r.isEmpty)throw Exception('Produk tidak ditemukan');final cur=(r.first['stock'] as num).toInt();if(cur+delta<0)throw Exception('Stok tidak boleh minus');await tx.update('products',{'stock':cur+delta},where:'id=?',whereArgs:[id]);await tx.insert('stock_movements',{'product_id':id,'type':delta>=0?'MASUK':'KELUAR','qty':delta.abs(),'note':note,'created_at':DateTime.now().toIso8601String()});});await log('STOK_DIUBAH','Produk $id delta $delta • $note');}

  Future<String> sale(Map<int,int> cart,num subtotal,num discount,num tax,num total,num received,String payment,{int? customerId,String cashier='Administrator'}) async {
    if(cart.isEmpty) throw Exception('Keranjang kosong.');
    if(subtotal<0||discount<0||tax<0||total<0||received<0) throw Exception('Nilai transaksi tidak valid.');
    if(payment=='Tunai'&&received<total) throw Exception('Pembayaran tunai kurang.');
    final invoice = await db.transaction((tx) async {for(final e in cart.entries){if(e.value<=0)throw Exception('Jumlah produk tidak valid.');final r=await tx.query('products',where:'id=? AND active=1',whereArgs:[e.key]);if(r.isEmpty)throw Exception('Produk tidak ditemukan');if((r.first['stock'] as num).toInt()<e.value)throw Exception('Stok tidak cukup: ${r.first['name']}');}final now=DateTime.now();final inv='INV-${DateFormatHelper.invoice(now)}';final sid=await tx.insert('sales',{'invoice':inv,'subtotal':subtotal,'discount':discount,'tax':tax,'total':total,'received':received,'payment_method':payment,'customer_id':customerId,'cashier':cashier,'created_at':now.toIso8601String()});for(final e in cart.entries){final p=(await tx.query('products',where:'id=?',whereArgs:[e.key])).first;await tx.insert('sale_items',{'sale_id':sid,'product_id':e.key,'qty':e.value,'price':p['price'],'buy_price':p['buy_price']??0,'discount':0});await tx.rawUpdate('UPDATE products SET stock=stock-? WHERE id=?',[e.value,e.key]);await tx.insert('stock_movements',{'product_id':e.key,'type':'PENJUALAN','qty':e.value,'note':inv,'created_at':now.toIso8601String()});}return inv;});
    await log('TRANSAKSI_DIBUAT','$invoice • $payment • total $total',user:cashier);
    return invoice;
  }
  Future<List<Map<String,dynamic>>> sales({String range='Hari Ini',String q=''}) async {String? where;List<dynamic>? args;if(range=='Hari Ini')where="date(created_at)=date('now','localtime')";else if(range=='7 Hari')where="datetime(created_at)>=datetime('now','-7 days','localtime')";else if(range=='Bulan Ini')where="strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime')";if(q.trim().isNotEmpty){where=where==null?'(invoice LIKE ? OR payment_method LIKE ? OR cashier LIKE ?)':'$where AND (invoice LIKE ? OR payment_method LIKE ? OR cashier LIKE ?)';args=['%$q%','%$q%','%$q%'];}return db.query('sales',where:where,whereArgs:args,orderBy:'id DESC',limit:500);}
  Future<List<Map<String,dynamic>>> saleItems(int id)=>db.rawQuery('SELECT si.*,p.name,p.unit FROM sale_items si LEFT JOIN products p ON p.id=si.product_id WHERE si.sale_id=?',[id]);
  Future<List<Map<String,dynamic>>> stockHistory(int id)=>db.query('stock_movements',where:'product_id=?',whereArgs:[id],orderBy:'id DESC',limit:200);
  Future<List<Map<String,dynamic>>> lowStock()=>db.query('products',where:'active=1 AND stock<=min_stock',orderBy:'stock');
  Future<Map<String,dynamic>> dashboard() async {final p=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE active=1'))??0;final t=Sqflite.firstIntValue(await db.rawQuery("SELECT COUNT(*) FROM sales WHERE date(created_at)=date('now','localtime')"))??0;final o=await db.rawQuery("SELECT COALESCE(SUM(total),0) x FROM sales WHERE date(created_at)=date('now','localtime')");final profit=await db.rawQuery("SELECT COALESCE(SUM((si.price*si.qty) - (si.buy_price*si.qty)),0) x FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)=date('now','localtime')");final exp=await db.rawQuery("SELECT COALESCE(SUM(amount),0) x FROM expenses WHERE date(created_at)=date('now','localtime')");final l=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM products WHERE active=1 AND stock<=min_stock'))??0;final sv=await db.rawQuery('SELECT COALESCE(SUM(stock*buy_price),0) x FROM products WHERE active=1');return {'products':p,'transactions':t,'omzet':o.first['x']??0,'profit':profit.first['x']??0,'expense':exp.first['x']??0,'lowStock':l,'stockValue':sv.first['x']??0};}
  Future<Map<String,String>> settings() async {final r=await db.query('store_settings');return {for(final x in r)x['key'].toString():(x['value']??'').toString()};}
  Future<void> setSettings(Map<String,String> v) async {await db.transaction((tx)async{for(final e in v.entries)await tx.insert('store_settings',{'key':e.key,'value':e.value},conflictAlgorithm:ConflictAlgorithm.replace);});}
  Future<List<Map<String,dynamic>>> users()=>db.query('users',where:'active=1',orderBy:'id');
  Future<void> saveUser(Map<String,dynamic> u)async{final d=Map<String,dynamic>.from(u)..remove('id');if(u['id']==null)await db.insert('users',d);else await db.update('users',d,where:'id=?',whereArgs:[u['id']]);}
  Future<void> deleteUser(int id)async{await db.update('users',{'active':0},where:'id=?',whereArgs:[id]);await log('USER_DIARSIPKAN','ID $id');}
  Future<List<Map<String,dynamic>>> customers()=>db.query('customers',where:'active=1',orderBy:'name');
  Future<void> saveCustomer(Map<String,dynamic> x)async{final d=Map<String,dynamic>.from(x)..remove('id');if(x['id']==null)await db.insert('customers',d);else await db.update('customers',d,where:'id=?',whereArgs:[x['id']]);}
  Future<void> deleteCustomer(int id)async{await db.update('customers',{'active':0},where:'id=?',whereArgs:[id]);await log('PELANGGAN_DIARSIPKAN','ID $id');}
  Future<List<Map<String,dynamic>>> expenses({String range='Hari Ini'})async{String? w;if(range=='Hari Ini')w="date(created_at)=date('now','localtime')";if(range=='Bulan Ini')w="strftime('%Y-%m',created_at)=strftime('%Y-%m','now','localtime')";return db.query('expenses',where:w,orderBy:'id DESC',limit:500);}
  Future<void> addExpense(String title,String category,num amount,String note)async{await db.insert('expenses',{'title':title,'category':category,'amount':amount,'note':note,'created_at':DateTime.now().toIso8601String()});await log('BIAYA',title);}
  Future<List<Map<String,dynamic>>> movementLog()=>db.rawQuery('SELECT sm.*,p.name FROM stock_movements sm LEFT JOIN products p ON p.id=sm.product_id ORDER BY sm.id DESC LIMIT 500');
  Future<List<Map<String,dynamic>>> audit()=>db.query('audit_log',orderBy:'id DESC',limit:300);
  Future<void> log(String action,String detail,{String user='Administrator'})async{await db.insert('audit_log',{'action':action,'detail':detail,'user_name':user,'created_at':DateTime.now().toIso8601String()});}
  Future<void> addPurchase(String supplier,Map<int,int> items)async{await db.transaction((tx)async{final now=DateTime.now();final inv='PO-${DateFormatHelper.invoice(now)}';num total=0;for(final e in items.entries){final r=await tx.query('products',where:'id=?',whereArgs:[e.key]);if(r.isNotEmpty)total+=(r.first['buy_price'] as num)*e.value;}final pid=await tx.insert('purchases',{'invoice':inv,'total':total,'supplier':supplier,'note':'Pembelian stok','created_at':now.toIso8601String()});for(final e in items.entries){final r=await tx.query('products',where:'id=?',whereArgs:[e.key]);if(r.isEmpty)continue;final cost=r.first['buy_price'] as num;await tx.insert('purchase_items',{'purchase_id':pid,'product_id':e.key,'qty':e.value,'cost':cost});await tx.rawUpdate('UPDATE products SET stock=stock+? WHERE id=?',[e.value,e.key]);await tx.insert('stock_movements',{'product_id':e.key,'type':'PEMBELIAN','qty':e.value,'note':inv,'created_at':now.toIso8601String()});}});}
}
class DateFormatHelper{static String invoice(DateTime d)=>'${d.year}${d.month.toString().padLeft(2,'0')}${d.day.toString().padLeft(2,'0')}-${d.hour.toString().padLeft(2,'0')}${d.minute.toString().padLeft(2,'0')}${d.second.toString().padLeft(2,'0')}${d.millisecond.toString().padLeft(3,'0')}';}
